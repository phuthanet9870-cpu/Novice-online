// Readable geometry placeholders driven exclusively by server-confirmed atlas events.
// These are not the finished per-skill pixel animations described in the PDF.
(function () {
  "use strict";
  const effects = [];
  const clock = () => performance.now() / 1000;
  const FX = (window.ATLAS_VFX = {
    effects,
    on(event) {
      const e = {
        ...event,
        at: clock(),
        duration: Math.max(0.05, event.d || 0.15),
      };
      if (e.uid) {
        const i = effects.findIndex((x) => x.uid === e.uid);
        if (i >= 0) effects.splice(i, 1);
      }
      if (e.phase === "dissolve") {
        for (const x of effects)
          if (x.s === e.s && x.sk === e.sk && x.phase === "persist")
            x.duration = Math.min(x.duration, clock() - x.at + 0.3);
        return;
      }
      effects.push(e);
      if (e.phase === "active" && window.G) {
        const caster = G.ents.get(e.s);
        if (caster) caster.attackAt = G.t;
      }
    },
    drawGround(g) {
      const t = clock();
      for (let i = effects.length - 1; i >= 0; i--)
        if (t - effects[i].at > effects[i].duration) effects.splice(i, 1);
      const important = effects.filter((e) =>
        ["prepare", "persist", "link"].includes(e.phase),
      );
      const decorative = effects
        .filter((e) => !important.includes(e))
        .slice(-24);
      for (const e of [...important, ...decorative])
        draw(g, e, (t - e.at) / e.duration);
    },
  });
  function draw(g, e, f) {
    const sk = NO_SKILLS.SKILLS[e.sk];
    if (!sk) return;
    const source = window.G && G.ents.get(e.s),
      hostile = window.G && e.s !== G.me && source && G.isEnemy(source),
      color = hostile ? "#ff784a" : "#70e1c5";
    g.save();
    g.lineWidth = 0.055;
    g.strokeStyle = color;
    g.fillStyle = color;
    g.globalAlpha =
      e.phase === "prepare"
        ? 0.25 + 0.15 * f
        : e.phase === "impact"
          ? (1 - f) * 0.75
          : 0.3;
    g.setLineDash(hostile ? [0.22, 0.09, 0.04, 0.09] : [0.04, 0.14]);
    const x = e.x,
      y = e.y,
      tx = e.tx ?? x,
      ty = e.ty ?? y,
      r = e.r || 0,
      type = e.type;
    if (e.phase === "travel") {
      const px = x + (tx - x) * f,
        py = y + (ty - y) * f;
      g.setLineDash([]);
      g.globalAlpha = 0.8;
      g.fillStyle = sk.fx.c[0];
      g.beginPath();
      g.arc(px, py, 0.14, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = "#fff";
      g.beginPath();
      g.moveTo(px, py);
      g.lineTo(px - (tx - x) * 0.035, py - (ty - y) * 0.035);
      g.stroke();
    } else if (e.phase === "link" || type === "wall") {
      g.beginPath();
      g.moveTo(x, y);
      g.lineTo(tx, ty);
      g.stroke();
      if (type === "wall") {
        g.setLineDash([]);
        g.globalAlpha = 0.1;
        g.lineWidth = 0.3;
        g.stroke();
      }
    } else if (["cone", "coneChannel"].includes(type)) {
      g.translate(x, y);
      g.rotate(e.angle || 0);
      const angle = ((e.cone || 100) * Math.PI) / 360;
      g.beginPath();
      g.moveTo(0, 0);
      g.arc(0, 0, r || e.len || 4, -angle, angle);
      g.closePath();
      g.stroke();
      g.globalAlpha *= 0.35;
      g.fill();
    } else if (
      [
        "line",
        "chargedLine",
        "pierce",
        "projectile",
        "snipe",
        "beam",
        "boomerang",
        "dash",
        "fan",
      ].includes(type)
    ) {
      g.translate(x, y);
      g.rotate(e.angle || 0);
      g.beginPath();
      g.rect(0, -(e.width || 1) / 2, e.len || sk.range || 3, e.width || 1);
      g.stroke();
      g.globalAlpha *= 0.35;
      g.fill();
    } else {
      let cx = tx,
        cy = ty;
      if (
        sk.self ||
        ["spin", "domain", "nova", "consumeArea", "orbit", "taunt"].includes(
          type,
        )
      ) {
        cx = x;
        cy = y;
      }
      if (e.phase === "impact") {
        g.strokeStyle = sk.fx.c[0];
        g.setLineDash([]);
        g.beginPath();
        g.arc(cx, cy, 0.15 + 0.35 * f, 0, Math.PI * 2);
        g.stroke();
      } else {
        g.beginPath();
        g.arc(cx, cy, r || 0.4, 0, Math.PI * 2);
        g.stroke();
        if (r) {
          g.globalAlpha *= 0.3;
          g.fill();
        }
        if (hostile && r) {
          g.globalAlpha = 0.65;
          g.setLineDash([]);
          for (let i = 0; i < 24; i++) {
            const a = (i * Math.PI) / 12;
            g.beginPath();
            g.moveTo(
              cx + Math.cos(a) * (r - 0.1),
              cy + Math.sin(a) * (r - 0.1),
            );
            g.lineTo(
              cx + Math.cos(a + 0.025) * r,
              cy + Math.sin(a + 0.025) * r,
            );
            g.stroke();
          }
        }
      }
    }
    g.restore();
  }
})();
