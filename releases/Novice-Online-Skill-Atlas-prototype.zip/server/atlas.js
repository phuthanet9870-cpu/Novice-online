"use strict";
// Authoritative skill atlas. Balance records contain data only; this module owns execution and validation.
const { SKILLS, ATLAS_CLASSES: CLASSES, CONFIG } = require("../shared/skills");
const M = require("../shared/mapgen");
const A = module.exports;
let C, W;
A.init = (combat, world) => {
  C = combat;
  W = world;
};
A.clock = () => Date.now() / 1000;
const now = () => A.clock();
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const prefix = (p) => CLASSES[p.cls].id;
const alive = (e) => e && !e.dead && e.hp > 0;
const send = (p, m) => p.sess && p.sess.send(m);
const fail = (p, m) => {
  send(p, { t: "err", m });
  return { ok: false, m };
};
const ids = (p) => new Set(p.char?.skillPassives || []);
A.has = (p, n) => ids(p).has(prefix(p) + "-P" + String(n).padStart(2, "0"));
A.proc = (p, n, cd, key = "") => {
  if (!A.has(p, n)) return false;
  const id = prefix(p) + "-P" + String(n).padStart(2, "0") + key;
  p.atlasProc ??= {};
  if ((p.atlasProc[id] || 0) > now()) return false;
  p.atlasProc[id] = now() + cd;
  return true;
};
A.power = (p, basis = CLASSES[p.cls].basis) =>
  basis === "P"
    ? p.st.atk
    : basis === "S"
      ? p.st.matk
      : Math.max(p.st.atk, p.st.matk);
A.visible = function (inst, a, b) {
  const length = dist(a, b),
    n = Math.max(1, Math.ceil(length * 8));
  for (let i = 0; i <= n; i++)
    if (
      !M.walkable(
        inst.map,
        a.x + ((b.x - a.x) * i) / n,
        a.y + ((b.y - a.y) * i) / n,
      )
    )
      return false;
  return true;
};
A.move = function (p, x, y) {
  const from = { x: p.x, y: p.y },
    n = Math.max(1, Math.ceil(Math.hypot(x - p.x, y - p.y) * 8));
  if (p.tags.has("root") || C.isHardCC(p)) return 0;
  for (let i = 1; i <= n; i++) {
    const nx = from.x + ((x - from.x) * i) / n,
      ny = from.y + ((y - from.y) * i) / n;
    if (!M.walkable(p.inst.map, nx, ny)) break;
    p.inst.moveTo(p, nx, ny);
  }
  p.forcePos = true;
  p.path = null;
  const moved = dist(p, from);
  if (moved) A.event(p, "move", { distance: moved, skill: true });
  return moved;
};
A.entities = (p, x, y, r, ally = false) => {
  const out = [];
  p.inst.inRadius(x, y, r + 0.5, (o) => {
    if (
      alive(o) &&
      ["p", "m", "s", "c"].includes(o.kind) &&
      (ally ? C.isAlly(p, o) : C.isEnemy(p, o)) &&
      Math.hypot(o.x - x, o.y - y) <= r &&
      (ally || !o.hidden) &&
      A.visible(p.inst, { x, y }, o)
    )
      out.push(o);
  });
  return out.sort(
    (a, b) =>
      Math.hypot(a.x - x, a.y - y) - Math.hypot(b.x - x, b.y - y) ||
      a.id - b.id,
  );
};
function seg(o, a, b) {
  const dx = b.x - a.x,
    dy = b.y - a.y,
    l = dx * dx + dy * dy || 1,
    u = Math.max(0, Math.min(1, ((o.x - a.x) * dx + (o.y - a.y) * dy) / l));
  return { u, d: Math.hypot(o.x - a.x - dx * u, o.y - a.y - dy * u) };
}
function line(ctx, a, b, width = 1) {
  return A.entities(
    ctx.p,
    (a.x + b.x) / 2,
    (a.y + b.y) / 2,
    dist(a, b) / 2 + width,
  )
    .filter((o) => seg(o, a, b).d <= width / 2)
    .sort((u, v) => seg(u, a, b).u - seg(v, a, b).u);
}
function cone(ctx, at, r, angle = 100) {
  return A.entities(ctx.p, at.x, at.y, r).filter(
    (o) =>
      Math.abs(
        Math.atan2(
          Math.sin(Math.atan2(o.y - at.y, o.x - at.x) - ctx.angle),
          Math.cos(Math.atan2(o.y - at.y, o.x - at.x) - ctx.angle),
        ),
      ) <=
      (angle * Math.PI) / 360,
  );
}
A.status = function (p, o) {
  const s = o?.atlasStatuses?.get(p.id);
  if (s && s.until > now()) return s;
  return null;
};
A.stacks = (p, o) => A.status(p, o)?.stacks || 0;
A.addStatus = function (p, o, n = 1) {
  if (!alive(o)) return 0;
  o.atlasStatuses ??= new Map();
  const old = A.status(p, o);
  if (o.atlasWinter?.has(p.id)) {
    n++;
    o.atlasWinter.delete(p.id);
  }
  const count = Math.min(5, (old?.stacks || 0) + n);
  o.atlasStatuses.set(p.id, {
    src: p,
    cls: p.cls,
    stacks: count,
    until: now() + 6,
    since: old?.since || now(),
    next: old?.next || now() + 1,
  });
  A.event(p, "status", {
    target: o,
    stacks: count,
    previous: old?.stacks || 0,
  });
  return count;
};
A.takeStatus = function (p, o) {
  const n = A.stacks(p, o);
  o?.atlasStatuses?.delete(p.id);
  return n;
};
A.resource = function (p, n, source = "direct") {
  if (!(n > 0)) return 0;
  const before = p.res || 0;
  let amount = n;
  if (source === "direct" && p.atlasResourceBuff > now())
    amount += Math.max(1, Math.floor(n * 0.5));
  if (source === "direct" && p.atlasExtraGain?.until > now()) {
    amount += p.atlasExtraGain.value;
    p.atlasExtraGain = null;
  }
  p.res = Math.min(CLASSES[p.cls].resource.max, before + amount);
  return p.res - before;
};
function gain(ctx, event) {
  const e = ctx.sk.atlas.effects.resource;
  if (!ctx.indirect && !ctx.ledger.resourceGiven && e.trigger === event) {
    ctx.ledger.resourceGiven = true;
    A.resource(ctx.p, e.gain);
  }
}
function fx(ctx, phase, extra = {}) {
  ctx.inst.emit({
    k: "atlas",
    s: ctx.p.id,
    sk: ctx.sk.id,
    phase,
    type: ctx.d.type,
    x: ctx.origin.x,
    y: ctx.origin.y,
    tx: ctx.aim.x,
    ty: ctx.aim.y,
    angle: ctx.angle,
    r: ctx.d.radius || 0,
    len: ctx.d.length || 0,
    width: ctx.d.width || 1,
    cone: ctx.d.angle || 100,
    d:
      phase === "prepare"
        ? ctx.windup
        : phase === "dissolve"
          ? ctx.sk.animation.dissolve
          : 0.18,
    placeholder: 1,
    ...extra,
  });
}
function later(ctx, delay, fn) {
  ctx.inst.after(delay, () => {
    if (
      ctx.p.inst === ctx.inst &&
      ctx.inst.entities.get(ctx.p.id) === ctx.p &&
      !ctx.p.dead &&
      !ctx.cancelled
    )
      fn();
  });
}
function valid(ctx, o, reach) {
  return (
    alive(o) &&
    o.inst === ctx.inst &&
    C.isEnemy(ctx.p, o) &&
    (!reach || dist(ctx.p, o) <= reach) &&
    A.visible(ctx.inst, ctx.p, o)
  );
}
A.control = function (p, o, control) {
  if (!control || !alive(o)) return false;
  const tag = control.tag;
  let duration = control.duration;
  const boss = o.kind === "m" && o.rank >= 2;
  if (boss && ["stun", "root", "fear", "airborne", "knockdown"].includes(tag)) {
    C.stagger(o, 20);
    return false;
  }
  if (o.kind === "p" && C.ownerP(p)) {
    duration = Math.min(CONFIG.pvp.controlCap, duration * CONFIG.pvp.control);
    o.atlasDR ??= {};
    let dr = o.atlasDR[tag];
    if (!dr || dr.until <= now())
      dr = o.atlasDR[tag] = { n: 0, until: now() + 6 };
    if (dr.n >= 2) return false;
    duration *= dr.n === 1 ? 0.5 : 1;
    dr.n++;
  }
  // Do not use legacy applyTag: that applies a different DR window and auto-freezes chill stacks.
  o.tags.set(tag, {
    stacks: 1,
    until: now() + duration,
    src: p,
    pct: control.pct || 0,
    soft: false,
    atlas: true,
  });
  if (
    ["stun", "fear", "silence", "airborne", "knockdown"].includes(tag) &&
    o.casting
  ) {
    A.interrupt(o);
    o.casting = null;
  }
  return true;
};
A.shield = function (p, o, value, duration, key) {
  if (!alive(o)) return 0;
  let amount = value * (p.inst?.pvp && o.kind === "p" ? CONFIG.pvp.shield : 1);
  for (const s of o.atlasStatuses?.values() || [])
    if (s.until > now() && s.cls === "shadowmancer")
      amount *= 1 - s.stacks * 0.02;
  if (p.cls === "seraph") {
    const e = A.entities(p, o.x, o.y, 4).find((e) => A.stacks(p, e));
    if (e) amount *= 1 + A.stacks(p, e) * 0.01;
  }
  o.atlasShields ??= new Map();
  const old = o.atlasShields.get(key),
    before = old?.amount || 0;
  o.atlasShields.set(key, {
    amount: Math.max(before, amount),
    until: Math.max(old?.until || 0, now() + duration),
    src: before > amount ? old.src : p,
  });
  o.shield = Math.max(0, (o.shield || 0) - before) + Math.max(before, amount);
  A.event(p, "shield", { target: o, amount });
  return amount;
};
function heal(ctx, o, mult, indirect = false) {
  if (!alive(o) || !C.isAlly(ctx.p, o)) return 0;
  const p = ctx.p;
  let value = p.st.matk * mult * ctx.boost;
  if (ctx.sk.atlas.effects.lowAllyBonus && o.hp < o.maxHp * 0.4) value *= 1.2;
  if (p.inst.pvp) value *= CONFIG.pvp.heal;
  if (!indirect && p.cls === "cleric") {
    const near = A.entities(p, o.x, o.y, 4).find((e) => A.stacks(p, e));
    if (near) value *= 1 + A.takeStatus(p, near) * 0.01;
    if (o.hp < o.maxHp * 0.35 && A.has(p, 1)) value *= 1.1;
  }
  if (p.cls === "druid" && ctx.d.type === "seed") {
    const near = A.entities(p, o.x, o.y, 4).find((e) => A.stacks(p, e));
    if (near) value *= 1 + A.stacks(p, near) * 0.02;
  }
  if (p.cls === "deity" && ctx.sk.needRes) {
    const near = A.entities(p, o.x, o.y, 4).find((e) => A.stacks(p, e));
    if (near) value *= 1 + A.stacks(p, near) * 0.02;
  }
  if (!indirect && p.atlasHealBonus > now()) {
    value *= 1.08;
    p.atlasHealBonus = 0;
  }
  if (!indirect && p.cls === "deity" && A.has(p, 2) && A.healSlots(p) >= 2)
    value *= 1.06;
  if (p.cls === "beastmaster" && A.has(p, 4) && o.atlasGroup === "companion")
    value *= 1.15;
  const missing = o.maxHp - o.hp,
    before = o.hp,
    got = C.heal(o, value, p);
  if (!indirect) {
    A.event(p, "heal", {
      target: o,
      got,
      before,
      overheal: Math.max(0, value - missing),
      ctx,
    });
    if (got > 0) gain(ctx, "condition");
  }
  return got;
}
function directBonus(ctx, o) {
  const p = ctx.p;
  let bonus = 0,
    stacks = A.stacks(p, o);
  const type = ctx.d.type,
    melee = ctx.range <= 4 && !ctx.d.speed;
  if (p.cls === "blademaster" && melee) bonus += stacks * 0.02;
  if (p.cls === "paladin" && ctx.sk.element === "holy") bonus += stacks * 0.02;
  if (p.cls === "spellblade" && melee) bonus += stacks * 0.02;
  if (p.cls === "marksman" && ["snipe", "chargedLine"].includes(type))
    bonus += stacks * 0.03;
  if (p.cls === "beastmaster" && type === "command") bonus += stacks * 0.03;
  if (p.cls === "starhunter" && ["orbit", "boomerang"].includes(type))
    bonus += stacks * 0.03;
  if (
    p.cls === "darkknight" &&
    o.atlasDisplaced?.by === p.id &&
    o.atlasDisplaced.until > now()
  )
    bonus += stacks * 0.02;
  if (
    p.cls === "lightbringer" &&
    o.hp > o.maxHp * 0.5 &&
    ctx.sk.element === "holy"
  )
    bonus += stacks * 0.02;
  if (p.cls === "reaper" && o.hp < o.maxHp * 0.35) bonus += stacks * 0.02;
  if (p.cls === "deity" && ctx.sk.needRes) bonus += stacks * 0.02;
  if (
    p.cls === "jester" &&
    ["trap", "mine", "grenade", "delayed"].includes(type)
  )
    bonus += stacks * 0.02;
  if (
    !ctx.indirect &&
    p.cls === "loki" &&
    Math.abs(
      Math.atan2(
        Math.sin(Math.atan2(p.y - o.y, p.x - o.x) - (o.dir || 0)),
        Math.cos(Math.atan2(p.y - o.y, p.x - o.x) - (o.dir || 0)),
      ),
    ) >
      Math.PI / 3
  )
    bonus += A.takeStatus(p, o) * 0.02;
  if (!ctx.indirect) bonus += A.damageBonus(ctx, o);
  return 1 + bonus;
}
function displace(ctx, o, distance, pull = false, center = ctx.origin) {
  if (!alive(o) || o.kind === "c") return false;
  if (o.kind === "m" && o.rank >= 2) {
    C.stagger(o, 20);
    return false;
  }
  if (o.kind === "p" && o.atlasConsent === false) return false;
  let a = Math.atan2(o.y - center.y, o.x - center.x) + (pull ? Math.PI : 0),
    amount = pull ? Math.min(distance, dist(o, center)) : distance;
  if (o.kind === "p" && o.st) amount *= 1 - (o.atlasDisplaceRes || 0);
  const moved = A.move(
    o,
    o.x + Math.cos(a) * amount,
    o.y + Math.sin(a) * amount,
  );
  if (moved) {
    o.atlasDisplaced = { by: ctx.p.id, until: now() + 2 };
    A.event(ctx.p, "displace", { target: o, ctx });
  }
  return moved > 0;
}
function hit(
  ctx,
  o,
  mult = ctx.d.damage || 0,
  { indirect = ctx.indirect, stacks = undefined, kind = "skill" } = {},
) {
  if (!valid(ctx, o)) return 0;
  if (o.kind === "p" && (o.god || o.gmf?.god || o.invulnUntil > now()))
    return 0;
  const p = ctx.p,
    d = ctx.d,
    oldStacks = stacks ?? A.stacks(p, o);
  let coefficient = mult;
  if (d.type === "execute" && o.hp / o.maxHp < d.threshold)
    coefficient = d.executeDamage;
  if (d.type === "backstab" && A.behind(p, o)) coefficient = d.backDamage;
  if (d.type === "consume" || d.type === "consumeArea") {
    const consumed = A.takeStatus(p, o);
    ctx.consumedStacks = consumed;
    ctx.totalConsumed = (ctx.totalConsumed || 0) + consumed;
    ctx.maxConsumed = Math.max(ctx.maxConsumed || 0, consumed);
    coefficient = d.damage + d.perStack * consumed;
  }
  let boost = ctx.boost;
  if (ctx.sk.id === "C01-A38" && ctx.charge >= 1 && oldStacks >= 3) {
    boost = 1;
    ctx.shieldPierce = 0.4;
  }
  const aliveBefore = alive(o),
    hpBefore = o.hp;
  const amount =
    coefficient * A.power(p) * boost * directBonus({ ...ctx, indirect }, o);

  const dealt = C.dealDamage(p, o, {
    power: amount,
    mult: 1,
    mag: CLASSES[p.cls].basis !== "P",
    el: ctx.sk.element,
    kind,
    sk: ctx.sk,
    atlas: true,
    indirect,
    shieldBonus: d.shieldBonus || ctx.shieldPierce || 0,
  });
  ctx.hits++;
  ctx.ledger.hits++;
  ctx.hitSet.add(o.id);
  const actual = Math.min(hpBefore, Math.max(0, dealt));
  const marks = o.atlasMarks?.get(p.id);
  if (!indirect && marks?.until > now() && marks.charges > 0) {
    marks.charges--;
    C.dealDamage(p, o, {
      power: A.power(p) * marks.damage,
      mag: CLASSES[p.cls].basis !== "P",
      kind: "skill",
      atlas: true,
      indirect: true,
      sk: ctx.sk,
      el: ctx.sk.element,
    });
  }
  if (!indirect) {
    gain(ctx, "hit");
    if (!ctx.marked.has(o.id) && ctx.sk.atlas.effects.applyStatus) {
      A.addStatus(p, o, ctx.sk.atlas.effects.applyStatus);
      ctx.marked.add(o.id);
    }
    if (p.atlasFirstStatus?.until > now()) {
      A.addStatus(p, o);
      p.atlasFirstStatus = null;
    }
    if (p.atlasFirstMana?.until > now()) {
      if (oldStacks) p.sp = Math.min(p.maxSp, p.sp + 5);
      p.atlasFirstMana = null;
    }
    if (
      ctx.sk.id === "C01-A12" &&
      ctx.previous === "C01-A01" &&
      ctx.hitIndex === 2 &&
      !ctx.comboMarked?.has(o.id)
    ) {
      ctx.comboMarked ??= new Set();
      ctx.comboMarked.add(o.id);
      A.addStatus(p, o);
    }
    if (
      ctx.sk.id === "C16-A04" &&
      /Kick|Heel/.test(SKILLS[ctx.previous]?.name || "") &&
      ctx.hitIndex === 2
    )
      A.addStatus(p, o);
    A.event(p, "hit", { target: o, got: actual, stacks: oldStacks, ctx });
    if (
      ctx.sk.kind === "attack" &&
      coefficient > 0 &&
      ![
        "echo",
        "summon",
        "command",
        "clone",
        "decoy",
        "turret",
        "mortar",
        "repairDrone",
      ].includes(d.type)
    ) {
      if (p.atlasEcho?.cast !== ctx.created)
        p.atlasEcho = {
          cast: ctx.created,
          origin: { ...ctx.origin },
          ctx: { ...ctx },
          targets: [],
          hits: [],
        };
      p.atlasEcho.targets.push(o);
      p.atlasEcho.hits.push({
        target: o,
        point: { x: o.x, y: o.y },
        coefficient: coefficient * boost,
      });
    }
  }
  if (d.control && (!indirect || ctx.persistent) && !ctx.controlled.has(o.id)) {
    A.control(p, o, d.control);
    ctx.controlled.add(o.id);
  }
  if (d.push && !indirect) displace(ctx, o, d.push);
  if (d.pull && !indirect)
    displace(ctx, o, d.pull, true, d.type === "circle" ? ctx.aim : ctx.origin);
  if (d.dot && !indirect && alive(o) && !ctx.dotted.has(o.id)) {
    o.atlasDots ??= new Map();
    o.atlasDots.set(p.id + ":" + ctx.sk.id, {
      p,
      sk: ctx.sk,
      until: now() + d.dot.duration,
      next: now() + 1,
      damage: d.dot.damage,
    });
    ctx.dotted.add(o.id);
  }
  if (d.drain && actual && o.owner !== p) {
    let ratio = d.drain + (p.cls === "warlock" ? oldStacks * 0.01 : 0),
      healed = actual * Math.min(0.25, ratio);
    if (o.kind === "p" && A.has(p, 2)) {
      const sec = Math.floor(now());
      if (p.atlasDrainSec !== sec) {
        p.atlasDrainSec = sec;
        p.atlasDrainUsed = 0;
      }
      healed = Math.min(
        healed,
        Math.max(0, p.maxHp * 0.06 - (p.atlasDrainUsed || 0)),
      );
      p.atlasDrainUsed = (p.atlasDrainUsed || 0) + healed;
    }
    C.heal(p, healed, p);
  }
  let stagger =
    10 * (1 + (ctx.sk.atlas.effects.markedStagger && oldStacks ? 0.3 : 0));
  stagger *= A.staggerBonus(ctx, o);
  if (p.cls === "monk") stagger *= 1 + oldStacks * 0.03;
  if (ctx.hitIndex === (d.hits || 1) - 1 && d.staggerLast)
    stagger *= d.staggerLast;
  C.stagger(o, stagger);
  fx(ctx, "impact", { x: o.x, y: o.y, tx: o.x, ty: o.y, r: 0.4, t: o.id });
  if (aliveBefore && !alive(o)) {
    if (!indirect) {
      if (d.type === "killReset" && !ctx.killReduced) {
        p.cds[ctx.sk.id] = now() + Math.max(0, p.cds[ctx.sk.id] - now()) * 0.5;
        ctx.killReduced = true;
        send(p, { t: "cd", id: ctx.sk.id, d: p.cds[ctx.sk.id] - now() });
      }
      if (oldStacks) gain(ctx, "killMarked");
    }
    A.event(p, "kill", { target: o, ctx, indirect, kind, stacks: oldStacks });
  }
  return actual;
}
A.behind = (p, o) =>
  !(o.cls === "ranger" && A.has(o, 4) && A.stacks(o, p) >= 3) &&
  Math.abs(
    Math.atan2(
      Math.sin(Math.atan2(p.y - o.y, p.x - o.x) - (o.dir || 0)),
      Math.cos(Math.atan2(p.y - o.y, p.x - o.x) - (o.dir || 0)),
    ),
  ) >
    Math.PI * 0.6;
A.absorb = function (o, amount) {
  o.shield = Math.max(0, (o.shield || 0) - Math.max(0, amount));
};

function context(p, sk, tgt, ax, ay) {
  const d = sk.atlas.delivery,
    range = d.range === null ? p.st.range : d.range;
  return {
    p,
    sk,
    d,
    inst: p.inst,
    tgt,
    origin: { x: p.x, y: p.y },
    aim: { x: ax, y: ay },
    angle: Math.atan2(ay - p.y, ax - p.x),
    range,
    boost: sk.needRes ? (sk.consumeRes ? 1.5 : 1.25) : 1,
    hits: 0,
    hitSet: new Set(),
    marked: new Set(),
    controlled: new Set(),
    dotted: new Set(),
    previous: p.atlasPrevious?.id,
    preStacks: A.stacks(p, tgt),
    deckIndex: p.atlasDeck || 0,
    preRes: p.res,
    ledger: { resourceGiven: false, hits: 0 },
    created: now(),
    hp: p.hp,
    windup: sk.cast,
    indirect: false,
  };
}
A.cost = function (p, sk) {
  let n = sk.sp,
    d = sk.atlas.delivery,
    pass = (i) => A.has(p, i);
  const before = p.atlasPrevious;
  if (
    p.atlasManaBuff?.until > now() &&
    p.atlasManaBuff.charges > 0 &&
    sk.kind === "attack"
  )
    n *= 0.7;
  if (p.cls === "berserker" && pass(2) && p.hp < p.maxHp * 0.4 && sk.needRes)
    n *= 0.85;
  if (
    p.cls === "cryomancer" &&
    pass(4) &&
    p.hp >= p.maxHp &&
    d.control &&
    ["slow", "root"].includes(d.control.tag)
  )
    n *= 0.9;
  if (
    p.cls === "cleric" &&
    pass(4) &&
    now() - (p.movedAt || 0) >= 1 &&
    ["heal", "partyHeal"].includes(d.type)
  )
    n *= 0.9;
  if (
    p.cls === "warlock" &&
    pass(5) &&
    p.hp < p.maxHp * 0.25 &&
    ["dash", "blink", "leap", "retreat", "charge", "hook", "portal"].includes(
      d.type,
    )
  )
    n *= 0.7;
  if (
    p.cls === "darkknight" &&
    pass(5) &&
    p.res >= 100 &&
    sk.atlas.effects.resource.gain &&
    sk.kind !== "ult"
  )
    n *= 0.85;
  if (
    p.cls === "seraph" &&
    pass(3) &&
    p.res <= 2 &&
    ["Choir Lance", "Return Feather"].includes(sk.name)
  )
    n *= 0.85;
  if (p.cls === "deity" && pass(3) && p.res < 20 && !sk.needRes) n *= 0.9;
  if (
    p.cls === "deity" &&
    pass(5) &&
    sk.kind === "ult" &&
    now() - (p.atlasLastUlt || p.atlasJoined || now()) > 60
  )
    n = Math.max(0, n - 10);
  if (
    p.atlasNextMana?.until > now() &&
    (!p.atlasNextMana.projectile || d.speed)
  )
    n *= 1 - p.atlasNextMana.value;
  if (
    p.cls === "starhunter" &&
    pass(5) &&
    ["orbit", "boomerang"].includes(d.type) &&
    ownField(p, null, "Charted Field")
  )
    n *= 0.9;
  return Math.max(0, n);
};
A.use = function (p, id, tid, ax, ay, mode = "cast") {
  const sk = SKILLS[id],
    t = now();
  if (!sk || !sk.atlas || sk.cls !== p.cls || sk.kind === "passive")
    return fail(p, "สกิลไม่ถูกต้อง");
  if (!p.char.skills?.[id] || !p.char.hotbar?.includes(id))
    return fail(p, "ต้องเรียนและใส่สกิลในชุดก่อน");
  if (!alive(p) || !p.inst) return fail(p, "ใช้ไม่ได้ขณะล้ม");
  if (C.isHardCC(p) || p.tags.has("silence"))
    return fail(p, "ถูกควบคุมหรือใบ้");
  const d = sk.atlas.delivery,
    moveTypes = [
      "dash",
      "leap",
      "blink",
      "retreat",
      "charge",
      "hook",
      "swap",
      "portal",
      "rescue",
      "interpose",
    ];
  if (moveTypes.includes(d.type) && p.tags.has("root"))
    return fail(p, "ถูกตรึง เคลื่อนที่ไม่ได้");
  if (
    (ax !== undefined && !Number.isFinite(ax)) ||
    (ay !== undefined && !Number.isFinite(ay)) ||
    (tid !== undefined && tid !== null && !Number.isSafeInteger(tid))
  )
    return fail(p, "พิกัดหรือเป้าหมายไม่ถูกต้อง");
  const recast = p.atlasRecasts?.[id];
  if (
    recast &&
    recast.until >= t &&
    !(d.type === "mine" && d.cap === 3 && mode !== "detonate")
  ) {
    if (t < recast.ready) return fail(p, "ยังเตรียมไม่เสร็จ");
    if (recast.ctx.inst !== p.inst) return fail(p, "แผนที่เปลี่ยน");
    delete p.atlasRecasts[id];
    if (p.casting?.sk.id === id) p.casting = null;
    A.recast(recast.ctx);
    return { ok: true, recast: true };
  }
  if (mode === "detonate" && d.type === "mine" && d.cap === 3)
    return fail(p, "ยังไม่มีทุ่นให้ระเบิด");
  if (p.casting || p.atlasChannel?.until > t) return fail(p, "กำลังร่าย");
  if ((p.cds[id] || 0) > t || p.atlasGcd > t) return fail(p, "คูลดาวน์");
  const inst = p.inst;
  let target = tid ? inst.entities.get(tid) : null;
  const ally = [
      "heal",
      "shield",
      "rescue",
      "interpose",
      "cleanse",
      "revive",
      "pairShield",
    ].includes(d.type),
    unit = d.type === "swap";
  if (
    target &&
    (target.inst !== inst ||
      target.hidden ||
      (!alive(target) && d.type !== "revive"))
  )
    return fail(p, "เป้าหมายไม่พร้อม");
  if (
    unit &&
    target &&
    (target.owner !== p ||
      !["clone", "decoy", "follower", "companion"].includes(target.atlasGroup))
  )
    return fail(p, "เลือกได้เฉพาะยูนิตของตน");
  if (ally) {
    if (!target) target = p;
    if (!C.isAlly(p, target)) return fail(p, "ต้องเลือกฝ่ายเดียวกัน");
    if (
      target.kind === "s" &&
      !(
        p.cls === "beastmaster" &&
        A.has(p, 4) &&
        target.atlasGroup === "companion"
      )
    )
      return fail(p, "สกิลนี้ใช้กับผู้เล่นเท่านั้น");
  } else if (target && !unit && !C.isEnemy(p, target))
    return fail(p, "เป้าหมายไม่ใช่ศัตรู");
  const range = d.range === null ? p.st.range : d.range;
  const targeted = [
    "single",
    "multi",
    "heavy",
    "riposte",
    "mark",
    "consume",
    "tether",
    "charge",
    "backstab",
    "killReset",
    "execute",
    "duel",
    "drain",
    "dispel",
    "delayed",
    "command",
    "swap",
    "heal",
    "shield",
    "cleanse",
    "revive",
    "rescue",
    "interpose",
  ];
  if (targeted.includes(d.type) && !target) return fail(p, "ต้องเลือกเป้าหมาย");
  if (
    target &&
    range > 0 &&
    (dist(p, target) > range || !A.visible(inst, p, target))
  )
    return fail(p, "เป้าหมายอยู่นอกระยะหรือหลังกำแพง");
  if (
    target?.kind === "p" &&
    C.isEnemy(p, target) &&
    target.stealthUntil > t &&
    dist(p, target) > 2
  )
    return fail(p, "มองไม่เห็นเป้าหมาย");
  if (d.type === "riposte" && !(p.atlasDefenseUntil >= t))
    return fail(p, "ต้องหลบหรือป้องกันสำเร็จในสองวินาที");
  if (d.type === "revive" && (inst.pvp || !target.dead || target.kind !== "p"))
    return fail(p, "ชุบได้เฉพาะผู้เล่นที่ล้มใน PvE");
  if (["command", "sacrifice", "recall"].includes(d.type) && !A.units(p).length)
    return fail(p, "ไม่มีผู้ติดตาม");
  if (d.type === "echo" && !p.atlasEcho)
    return fail(p, "ไม่มีสกิลโจมตีตรงให้คัดลอก");
  if (
    ((d.consent && d.type !== "partyRewind") || d.type === "interpose") &&
    target !== p &&
    !target.char?.allowAtlasRescue
  )
    return fail(p, "พันธมิตรยังไม่ยินยอมการย้ายตำแหน่ง");
  const cost = A.cost(p, sk);
  if (p.sp < cost) return fail(p, "MP ไม่พอ");
  if (p.res < sk.needRes) return fail(p, "ทรัพยากรเฉพาะคลาสไม่พอ");
  if (d.hpMinimum && p.hp / p.maxHp < d.hpMinimum)
    return fail(p, "HP ต่ำกว่าขั้นต่ำ");
  if (ax === undefined || ay === undefined) {
    ax = target?.x ?? p.x + Math.cos(p.dir || 0) * (range || 1);
    ay = target?.y ?? p.y + Math.sin(p.dir || 0) * (range || 1);
  }
  const aim = { x: ax, y: ay },
    ad = dist(p, aim);
  if (range > 0 && ad > range) {
    aim.x = p.x + ((ax - p.x) / ad) * range;
    aim.y = p.y + ((ay - p.y) / ad) * range;
  }
  if (range > 0 && !A.visible(inst, p, aim))
    return fail(p, "พื้นที่เป้าหมายมองไม่เห็น");
  const ctx = context(p, sk, target, aim.x, aim.y);
  ctx.manaPaid = cost;
  p.sp -= cost;
  p.res = Math.max(0, p.res - sk.needRes);
  p.atlasLastCast = t;
  p.atlasGcd = t + CONFIG.globalCooldown;
  p.lastHit = t;
  if (d.hpCost) {
    const ratio =
      p.cls === "berserker" && A.has(p, 5) && ctx.preRes >= 100
        ? 0.06
        : d.hpCost;
    p.hp = Math.max(1, p.hp * (1 - ratio));
    for (const z of p.atlasFields || []) z.ctx.hurt = true;
    if (p.atlasGuard) p.atlasGuard.ctx.hurt = true;
    if (p.atlasStance) p.atlasStance.ctx.hurt = true;
    A.event(p, "hpPayment", { ctx });
  }
  if (p.atlasManaBuff?.until > t && sk.kind === "attack")
    p.atlasManaBuff.charges--;
  p.atlasNextMana = null;
  const cd =
    sk.cd *
    (1 - Math.min(60, Math.max(0, (p.st.cdr || 0) + (p.cdrBonus || 0))) / 100);
  p.cds[id] = t + cd;
  send(p, { t: "cd", id, d: cd });
  p.atlasPrevious = { id, at: t, type: d.type, category: sk.kind };
  if (sk.kind === "ult") p.atlasLastUlt = t;
  ctx.windup = Math.max(0.15, sk.cast);
  if (p.atlasNextCast?.until > t && sk.kind !== "ult") {
    ctx.windup *= 0.85;
    p.atlasNextCast = null;
  }
  if (p.cls === "marksman" && sk.name === "Braced Shot" && p.atlasReloadCast) {
    ctx.windup *= 0.85;
    p.atlasReloadCast = false;
  }
  A.event(p, "cast", { ctx, previous: ctx.previous });
  if (d.type === "tripleImpact")
    for (let i = 1; i <= 3; i++) {
      const x = ctx.origin.x + (Math.cos(ctx.angle) * d.length * i) / 3,
        y = ctx.origin.y + (Math.sin(ctx.angle) * d.length * i) / 3;
      fx(ctx, "prepare", { x, y, tx: x, ty: y, r: d.radius, type: "circle" });
    }
  else fx(ctx, "prepare");
  p.dir = ctx.angle;
  if (d.recast) {
    p.atlasRecasts ??= {};
    const duration =
      d.type === "chargedLine"
        ? 1
        : d.type === "mine" && d.cap === 3
          ? Infinity
          : d.duration || 8;
    p.atlasRecasts[id] = {
      ctx,
      ready:
        t +
        (d.type === "feint"
          ? 0.5
          : d.type === "chargedLine"
            ? 0.15
            : ctx.windup),
      until: t + duration,
    };
    if (d.type === "feint") {
      ctx.feint = true;
      return { ok: true };
    }
    if (d.type === "chargedLine") {
      p.casting = {
        sk,
        lv: 1,
        ax: ctx.aim.x,
        ay: ctx.aim.y,
        tgtId: target?.id,
        until: t + 1,
        start: t,
        atlas: ctx,
      };
      return { ok: true, cast: 1 };
    }
  }
  p.casting = {
    sk,
    lv: 1,
    ax: ctx.aim.x,
    ay: ctx.aim.y,
    tgtId: target?.id,
    until: t + ctx.windup,
    start: t,
    atlas: ctx,
  };
  return { ok: true, cast: ctx.windup };
};
A.interrupt = function (p) {
  const ctx = p.casting?.atlas;
  if (ctx) {
    ctx.cancelled = true;
    if (
      p.cls === "marksman" &&
      ["snipe", "chargedLine"].includes(ctx.d.type) &&
      A.has(p, 5)
    )
      p.sp = Math.min(p.maxSp, p.sp + ctx.manaPaid * 0.5);
    if (ctx.preRes >= CLASSES[p.cls].resource.max) {
      if (p.cls === "blademaster" && A.proc(p, 3, 12))
        p.res = Math.max(0, ctx.preRes - 1);
      else if (!ctx.sk.needRes) p.res = 0;
    }
    delete p.atlasRecasts?.[ctx.sk.id];
  }
  if (p.atlasChannel) p.atlasChannel.ctx.cancelled = true;
  p.atlasChannel = null;
};
A.units = (p) =>
  (p.summons || []).filter(
    (s) =>
      alive(s) &&
      s.inst === p.inst &&
      ["follower", "companion", "repair"].includes(s.atlasGroup),
  );
A.exec = function (p, sk, tgt, ax, ay, ctx) {
  if (!ctx) return;
  ctx.charge =
    ctx.d.type === "chargedLine" ? Math.min(1, now() - ctx.created) : 0;
  if (ctx.d.type === "chargedLine") {
    ctx.d = {
      ...ctx.d,
      damage: ctx.d.damage + (ctx.d.maxDamage - ctx.d.damage) * ctx.charge,
    };
    delete p.atlasRecasts?.[sk.id];
  }
  A.resolve(ctx);
};
A.recast = function (ctx) {
  const p = ctx.p;
  switch (ctx.d.type) {
    case "feint":
      A.resolve(ctx);
      break;
    case "chargedLine":
      A.exec(p, ctx.sk, ctx.tgt, ctx.aim.x, ctx.aim.y, ctx);
      break;
    case "mine":
      for (const z of p.atlasFields || [])
        if (z.ctx.sk.id === ctx.sk.id && z.until > now()) {
          z.until = 0;
          for (const o of A.entities(p, z.x, z.y, z.r)) hit(z.ctx, o);
        }
      break;
    case "rewind": {
      const old = ctx.memory;
      if (old) {
        A.move(p, old.x, old.y);
        const got = C.heal(
          p,
          Math.min(Math.max(0, old.hp - p.hp), p.maxHp * ctx.d.healHp),
          p,
        );
        A.event(p, "rewind", { got, ctx });
      }
      break;
    }
    case "portal":
      if (ctx.memory) {
        A.move(p, ctx.memory.x, ctx.memory.y);
        A.event(p, "portalReturn", { ctx });
      }
      break;
    default:
      throw Error("Unhandled recast " + ctx.d.type);
  }
  fx(ctx, "dissolve");
};
function allies(ctx, r = ctx.d.radius || ctx.range, center = ctx.origin) {
  return [
    ctx.p,
    ...A.entities(ctx.p, center.x, center.y, r, true).filter(
      (o) => o !== ctx.p && o.kind === "p",
    ),
  ].slice(0, ctx.d.maxTargets || 5);
}
function field(
  ctx,
  {
    x = ctx.aim.x,
    y = ctx.aim.y,
    r = ctx.d.radius || 1,
    duration = ctx.d.type === "mine" && ctx.d.cap === 3
      ? Infinity
      : ctx.d.duration || 8,
    kind = ctx.d.type,
  } = {},
) {
  const z = {
    ctx,
    x,
    y,
    r,
    kind,
    at: now(),
    until: now() + duration,
    next: now() + 1,
    inst: ctx.inst,
  };
  ctx.p.atlasFields ??= [];
  ctx.p.atlasFields.push(z);
  gain(ctx, "success");
  fx(ctx, "persist", {
    x,
    y,
    tx: x,
    ty: y,
    r,
    d: duration,
    uid: ctx.sk.id + ":" + ctx.created,
  });
  return z;
}
function once(ctx, targets) {
  for (const o of targets.slice(0, ctx.d.maxTargets || 40)) hit(ctx, o);
}
function pulses(ctx, targets) {
  if (ctx.d.channel || ["coneChannel", "drain"].includes(ctx.d.type))
    ctx.p.atlasChannel = {
      ctx,
      until: now() + (ctx.d.channel || ctx.d.hits * ctx.d.interval),
      x: ctx.p.x,
      y: ctx.p.y,
    };
  for (let i = 0; i < (ctx.d.hits || 1); i++)
    later(ctx, i * (ctx.d.interval || 0.15), () => {
      if (
        ["coneChannel", "drain", "beam", "circleChannel"].includes(
          ctx.d.type,
        ) &&
        (C.isHardCC(ctx.p) || ctx.p.tags.has("silence"))
      )
        return A.interrupt(ctx.p);
      ctx.hitIndex = i;
      once(ctx, targets());
    });
}
function shoot(ctx, a, b, damage = ctx.d.damage, cap = ctx.d.maxTargets || 1) {
  const speed = ctx.d.speed || 18,
    travel = dist(a, b) / speed;
  fx(ctx, "travel", { x: a.x, y: a.y, tx: b.x, ty: b.y, d: travel });
  const targets = line(ctx, a, b, ctx.d.width || 0.5).slice(0, cap);
  for (const o of targets) {
    const point = { x: o.x, y: o.y };
    later(ctx, dist(a, point) / speed, () => {
      if (valid(ctx, o) && dist(o, point) < 0.8 && !A.blocked(ctx, a, o))
        hit(ctx, o, damage);
    });
  }
}
A.resolve = function (ctx) {
  const { p, d, sk, tgt } = ctx,
    origin = ctx.origin,
    aim = ctx.aim;
  ctx.windup = 0;
  fx(ctx, "active");
  const selected = () =>
    valid(ctx, tgt, ctx.d.breakRange || ctx.range || p.st.range) ? [tgt] : [];
  const around = () => A.entities(p, origin.x, origin.y, d.radius || 3);
  const forward = {
    x: origin.x + Math.cos(ctx.angle) * (d.length || ctx.range),
    y: origin.y + Math.sin(ctx.angle) * (d.length || ctx.range),
  };
  switch (d.type) {
    case "single":
    case "heavy":
    case "riposte":
    case "shieldbreak":
    case "backstab":
    case "execute":
    case "killReset":
    case "bloodNova":
    case "feint":
      once(ctx, d.type === "bloodNova" ? around() : selected());
      break;
    case "multi":
    case "duel":
    case "drain":
      pulses(ctx, selected);
      break;
    case "cone":
      once(ctx, cone(ctx, origin, d.radius, d.angle));
      break;
    case "coneChannel":
      pulses(ctx, () => cone(ctx, origin, d.radius, d.angle));
      break;
    case "spin":
      pulses(ctx, around);
      break;
    case "circle":
    case "grenade":
    case "nova":
    case "clearZone":
    case "consumeArea":
    case "circleMulti":
    case "rain": {
      const at = ["nova", "consumeArea", "clearZone"].includes(d.type)
        ? origin
        : aim;
      const get = () => A.entities(p, at.x, at.y, d.radius);
      if (d.edgeMult) {
        for (const o of get())
          hit(
            ctx,
            o,
            d.damage * (dist(o, at) > d.radius * 0.5 ? d.edgeMult : 1),
          );
      } else if (d.hits) pulses(ctx, get);
      else once(ctx, get());
      if (d.type === "clearZone") {
        let remaining = 1;
        for (const q of ctx.inst.players)
          for (const z of q.atlasFields || [])
            if (
              remaining &&
              z.until > now() &&
              C.isEnemy(p, q) &&
              z.removable !== false &&
              Math.hypot(z.x - at.x, z.y - at.y) <= d.radius
            ) {
              z.until = 0;
              remaining--;
            }
      }
      break;
    }
    case "line":
    case "chargedLine": {
      const list = line(ctx, origin, forward, d.width);
      list.forEach((o, i) =>
        hit(ctx, o, d.damage * (i && d.secondary ? d.secondary : 1)),
      );
      break;
    }
    case "pierce":
    case "projectile":
    case "snipe":
      shoot(ctx, origin, forward, d.damage, d.maxTargets || 5);
      break;
    case "fan":
      for (let i = 0; i < 5; i++) {
        const angle = ctx.angle + (i - 2) * 0.14,
          b = {
            x: origin.x + Math.cos(angle) * d.length,
            y: origin.y + Math.sin(angle) * d.length,
          };
        const ray = { ...ctx, d: { ...d }, hitSet: ctx.hitSet };
        const candidates = line(ctx, origin, b, d.width).slice(0, 1);
        for (const o of candidates) {
          ctx.fanHits ??= new Map();
          const n = ctx.fanHits.get(o.id) || 0;
          if (n < 3) {
            ctx.fanHits.set(o.id, n + 1);
            shoot(ray, origin, b, d.damage, 1);
          }
        }
      }
      break;
    case "boomerang": {
      const out = line(ctx, origin, forward, d.width);
      shoot(ctx, origin, forward, d.damage, 40);
      later(ctx, d.length / 18, () => {
        const back = { x: p.x, y: p.y };
        if (dist(forward, back) + d.length > d.maxTravel) return;
        const backHits = line(ctx, forward, back, d.width);
        shoot(ctx, forward, back, d.damage, 40);
        if (
          p.cls === "starhunter" &&
          out.some((o) => backHits.includes(o)) &&
          A.proc(p, 1, 4)
        )
          A.resource(p, 5, "passive");
      });
      break;
    }
    case "chain": {
      let current = tgt || A.entities(p, aim.x, aim.y, 2)[0],
        seen = new Set(),
        index = 0;
      while (current && index < (d.maxTargets || 4)) {
        seen.add(current.id);
        const from = index ? ctx.chainFrom : origin;
        fx(ctx, "link", {
          x: from.x,
          y: from.y,
          tx: current.x,
          ty: current.y,
          d: 0.3,
        });
        hit(ctx, current, index ? d.secondary : d.damage);
        ctx.chainFrom = current;
        const radius =
          d.chainRange +
          (p.cls === "stormcaller" ? A.stacks(p, current) * 0.3 : 0);
        let next = A.entities(p, current.x, current.y, radius).filter(
          (o) => !seen.has(o.id),
        );
        if (sk.id === "C07-A03")
          next.sort((a, b) => A.stacks(p, b) - A.stacks(p, a) || a.id - b.id);
        current = next[0];
        index++;
      }
      if (
        index === 1 &&
        p.cls === "stormcaller" &&
        A.has(p, 3) &&
        ctx.chainFrom
      )
        hit({ ...ctx, indirect: true }, ctx.chainFrom, 0.3);
      break;
    }
    case "dash":
    case "leap":
    case "blink":
    case "retreat":
    case "charge":
    case "hook": {
      let destination = aim;
      if (["dash", "retreat"].includes(d.type)) {
        const a = ctx.angle + (d.type === "retreat" ? Math.PI : 0);
        destination = {
          x: origin.x + Math.cos(a) * d.length,
          y: origin.y + Math.sin(a) * d.length,
        };
      }
      const moved = A.move(p, destination.x, destination.y);
      if (moved >= 3 && moved >= dist(origin, destination) - 0.15)
        gain(ctx, "move3");
      if (d.type === "dash") once(ctx, line(ctx, origin, p, d.width));
      else if (d.type === "leap") once(ctx, A.entities(p, p.x, p.y, d.radius));
      else if (d.type === "retreat") once(ctx, cone(ctx, origin, 4, 100));
      else if (["charge", "hook"].includes(d.type) && tgt && dist(p, tgt) <= 2)
        once(ctx, [tgt]);
      A.event(p, "movementSkill", { ctx, distance: moved });
      fx(ctx, "travel", { x: origin.x, y: origin.y, tx: p.x, ty: p.y, d: 0.2 });
      break;
    }
    case "tripleImpact":
      for (let i = 0; i < 3; i++) {
        const at = {
          x: origin.x + (Math.cos(ctx.angle) * d.length * (i + 1)) / 3,
          y: origin.y + (Math.sin(ctx.angle) * d.length * (i + 1)) / 3,
        };
        for (const o of A.entities(p, at.x, at.y, d.radius)) {
          ctx.pointHits ??= new Map();
          const n = ctx.pointHits.get(o.id) || 0;
          if (n < 2) {
            hit(ctx, o);
            ctx.pointHits.set(o.id, n + 1);
          }
        }
      }
      break;
    case "consume":
      once(ctx, selected());
      break;
    case "mark":
      if (valid(ctx, tgt, ctx.range)) {
        if (sk.id === "C02-A21" && tgt.kind === "m" && tgt.rank < 2)
          tgt.atlasCover = p;
        tgt.atlasMarks ??= new Map();
        tgt.atlasMarks.set(p.id, {
          until: now() + d.duration,
          charges: 3,
          damage: d.damage,
        });
        if (sk.atlas.effects.applyStatus)
          A.addStatus(p, tgt, sk.atlas.effects.applyStatus);
        gain(ctx, "hit");
      }
      break;
    case "spread":
      if (valid(ctx, tgt, ctx.range)) {
        const source =
          sk.id === "C15-A38"
            ? A.entities(p, p.x, p.y, ctx.range).sort(
                (a, b) => A.stacks(p, b) - A.stacks(p, a) || a.id - b.id,
              )[0] || tgt
            : tgt;
        const count = A.stacks(p, source),
          near = A.entities(p, source.x, source.y, d.radius)
            .filter((o) => o !== source)
            .slice(0, 4);
        for (const o of near)
          if (count && !A.stacks(p, o)) A.addStatus(p, o, count);
      }
      break;
    case "tether":
      if (valid(ctx, tgt, ctx.range)) {
        ctx.tether = { x: tgt.x, y: tgt.y, target: tgt };
        field(ctx, { x: tgt.x, y: tgt.y, r: d.breakRange });
        if (sk.atlas.effects.applyStatus) {
          A.addStatus(p, tgt);
          ctx.marked.add(tgt.id);
        }
      }
      break;
    case "parry":
    case "guard":
      p.atlasGuard = {
        ctx,
        until: now() + d.duration,
        reduction: d.reduction,
        hp: p.hp,
        used: false,
        angle: p.dir,
      };
      if (d.type === "guard")
        C.addBuff(p, sk.id, { movePct: -50 }, d.duration, sk.name);
      field(ctx, { x: p.x, y: p.y, r: 0 });
      break;
    case "stance":
      p.atlasStance = { ctx, until: now() + d.duration, hp: p.hp };
      field(ctx, { x: p.x, y: p.y, r: 0 });
      break;
    case "buff":
    case "partyBuff":
    case "transform":
    case "pairShield":
    case "manaBuff":
    case "resourceBuff":
    case "regenBuff": {
      const qs =
        d.type === "partyBuff"
          ? allies(ctx, d.radius)
          : d.type === "pairShield"
            ? [p, ...(tgt && tgt !== p ? [tgt] : [])]
            : [p];
      let duration = d.duration * (sk.kind === "buff" && sk.needRes ? 1.2 : 1);
      for (const q of qs) {
        if (d.mods)
          C.addBuff(
            q,
            sk.id,
            d.mods,
            duration +
              (sk.atlas.effects.lowAllyDuration && q.hp < q.maxHp * 0.4
                ? 1
                : 0),
            sk.name,
          );
        if (d.shieldHp)
          A.shield(
            p,
            q,
            p.maxHp * d.shieldHp * (sk.needRes ? 1.2 : 1),
            duration,
            sk.id,
          );
      }
      if (d.type === "manaBuff")
        p.atlasManaBuff = { until: now() + duration, charges: 3 };
      if (d.type === "resourceBuff") p.atlasResourceBuff = now() + duration;
      if (d.type === "transform")
        p.atlasTransform = { ctx, until: now() + duration };
      if (sk.atlas.effects.firstHitStatus)
        p.atlasFirstStatus = { until: now() + duration };
      if (sk.atlas.effects.firstMarkedMana)
        p.atlasFirstMana = { until: now() + duration };
      field(ctx, { x: p.x, y: p.y, r: 0, duration });
      gain(ctx, "success");
      break;
    }
    case "taunt":
      for (const o of around()) {
        if (o.kind === "m" && o.rank < 2) {
          o.target = p;
          o.tauntBy = p;
          o.tauntUntil = now() + 2;
        } else if (o.kind === "p")
          o.atlasTaunt = { by: p.id, until: now() + 2 };
        gain(ctx, "hit");
      }
      gain(ctx, "condition");
      break;
    case "heal":
      heal(ctx, tgt, d.heal);
      break;
    case "partyHeal":
      for (const o of allies(ctx, d.radius || d.range)) {
        heal(ctx, o, d.heal);
        if (d.shield)
          A.shield(p, o, p.st.matk * d.shield * ctx.boost, d.duration, sk.id);
      }
      break;
    case "shield":
      if (tgt)
        A.shield(
          p,
          tgt,
          p.st.matk *
            d.shield *
            ctx.boost *
            (sk.atlas.effects.lowAllyBonus && tgt.hp < tgt.maxHp * 0.4
              ? 1.2
              : 1),
          d.duration,
          sk.id,
        );
      break;
    case "cleanse": {
      if (A.cleanse(p, tgt, d.maxRemove, ctx)) gain(ctx, "cleanse");
      break;
    }
    case "dispel":
      if (valid(ctx, tgt, ctx.range)) {
        const buffs = [...(tgt.buffs || [])]
          .filter(
            ([k, b]) =>
              !k.includes("-U") &&
              !b.locked &&
              !b.boss &&
              !b.passive &&
              !b.item,
          )
          .sort((a, b) => b[1].until - a[1].until);
        if (buffs[0]) {
          C.removeBuff(tgt, buffs[0][0]);
          A.event(p, "dispel", { ctx, target: tgt });
          gain(ctx, "condition");
        }
        hit(ctx, tgt);
      }
      break;
    case "revive":
      if (tgt.dead && !ctx.inst.pvp && tgt.inst === ctx.inst) {
        tgt.dead = false;
        tgt.hp = tgt.maxHp * 0.25;
        send(tgt, { t: "revived" });
        A.event(p, "revive", { target: tgt, ctx });
      }
      break;
    case "rescue":
    case "interpose":
      if (tgt && alive(tgt) && tgt !== p && tgt.char?.allowAtlasRescue) {
        if (d.type === "rescue") {
          A.move(tgt, p.x, p.y);
          A.shield(
            p,
            tgt,
            p.st.matk *
              d.shield *
              ctx.boost *
              (tgt.hp < tgt.maxHp * 0.4 ? 1.2 : 1),
            d.duration,
            sk.id,
          );
          A.event(p, "rescue", { target: tgt, ctx });
        } else {
          A.move(p, tgt.x, tgt.y);
          p.atlasInterpose = { target: tgt, until: now() + 3, ctx };
          gain(ctx, "condition");
        }
      }
      break;
    case "zone":
    case "domain":
    case "healingZone":
    case "sanctuary":
    case "slowZone":
      field(ctx, {
        x: d.range === 0 ? origin.x : aim.x,
        y: d.range === 0 ? origin.y : aim.y,
      });
      break;
    case "beam":
      pulses(ctx, () => line(ctx, origin, forward, d.width));
      break;
    case "circleChannel":
      pulses(ctx, around);
      break;
    case "mine": {
      const mine = field(ctx);
      mine.next = Infinity;
      const same = p.atlasFields.filter(
        (z) => z.kind === "mine" && z.ctx.sk.id === sk.id && z.until > now(),
      );
      while (same.length > d.cap) same.shift().until = 0;
      break;
    }
    case "trap":
    case "seed":
      field(ctx);
      break;
    case "wall": {
      const z = field(ctx, {
        x: p.x + Math.cos(ctx.angle),
        y: p.y + Math.sin(ctx.angle),
        r: 0,
      });
      z.a = {
        x: z.x + Math.cos(ctx.angle + Math.PI / 2) * 2.5,
        y: z.y + Math.sin(ctx.angle + Math.PI / 2) * 2.5,
      };
      z.b = {
        x: z.x - Math.cos(ctx.angle + Math.PI / 2) * 2.5,
        y: z.y - Math.sin(ctx.angle + Math.PI / 2) * 2.5,
      };
      fx(ctx, "persist", {
        x: z.a.x,
        y: z.a.y,
        tx: z.b.x,
        ty: z.b.y,
        type: "wall",
        d: 3,
      });
      break;
    }
    case "stealth":
      p.stealthUntil = now() + 3;
      field(ctx, { x: p.x, y: p.y, r: 0 });
      break;
    case "orbit": {
      const z = field(ctx, { x: p.x, y: p.y, r: d.radius });
      z.orbs = [true, true, true];
      z.orbitTargets = new Set();
      break;
    }
    case "slowOrb": {
      const z = field(ctx, { x: origin.x, y: origin.y, r: d.radius });
      z.direction = ctx.angle;
      z.hitTimes = new Map();
      break;
    }
    case "summon":
    case "turret":
    case "mortar":
    case "repairDrone":
    case "clone":
    case "decoy":
    case "army":
      A.spawn(ctx);
      break;
    case "command": {
      const units = A.units(p),
        chosen = units.sort((a, b) =>
          a.atlasGroup === "companion"
            ? -1
            : b.atlasGroup === "companion"
              ? 1
              : dist(a, aim) - dist(b, aim),
        )[0];
      if (
        chosen &&
        valid(ctx, tgt, ctx.range) &&
        A.visible(ctx.inst, chosen, tgt)
      ) {
        hit(
          { ...ctx, indirect: true, d: { type: "command" } },
          tgt,
          d.damage * (p.atlasRoyal?.until > now() ? 1.15 : 1),
        );
        p.atlasRoyal = null;
        if (chosen.atlasSpec.commandPush) displace(ctx, tgt, 1);
        gain(ctx, "hit");
        A.event(p, "command", { target: tgt, ctx });
      }
      break;
    }
    case "sacrifice": {
      const unit = A.units(p).sort((a, b) => dist(a, aim) - dist(b, aim))[0];
      if (unit) {
        A.event(p, "sacrifice", { unit, ctx });
        const at = { x: unit.x, y: unit.y };
        unit.atlasEnd = "sacrifice";
        W.killQuiet(unit);
        once(ctx, A.entities(p, at.x, at.y, d.radius));
      }
      break;
    }
    case "recall":
      for (const s of A.units(p)) {
        A.move(s, p.x, p.y);
        C.heal(s, s.maxHp * d.healHp, p);
      }
      gain(ctx, "condition");
      break;
    case "swap":
      if (tgt && tgt.owner === p && alive(tgt) && A.visible(ctx.inst, p, tgt)) {
        const from = { x: p.x, y: p.y };
        A.move(p, tgt.x, tgt.y);
        A.move(tgt, from.x, from.y);
        A.event(p, "swap", { ctx });
        gain(ctx, "condition");
      }
      break;
    case "portal":
      ctx.memory = { ...origin };
      A.move(p, aim.x, aim.y);
      field(ctx, { x: origin.x, y: origin.y, r: 0.6 });
      break;
    case "rewind":
      ctx.memory = { x: p.x, y: p.y, hp: p.hp };
      field(ctx, { x: p.x, y: p.y, r: 0.6 });
      break;
    case "partyRewind": {
      const qs = allies(ctx, d.radius).filter(
        (q) => q === p || q.char?.allowAtlasRescue,
      );
      const memories = qs.map((q) => ({
        q,
        inst: q.inst,
        x: q.x,
        y: q.y,
        hp: q.hp,
      }));
      later(ctx, 3, () => {
        for (const m of memories)
          if (
            alive(m.q) &&
            m.q.inst === m.inst &&
            (m.q === p || m.q.char?.allowAtlasRescue)
          ) {
            A.move(m.q, m.x, m.y);
            C.heal(
              m.q,
              Math.min(Math.max(0, m.hp - m.q.hp), m.q.maxHp * 0.2),
              p,
            );
          }
      });
      break;
    }
    case "morph":
      p.atlasMorph = { ctx, until: now() + d.duration };
      field(ctx, { x: p.x, y: p.y, r: 0 });
      break;
    case "echo": {
      const saved = p.atlasEcho,
        fraction =
          p.cls === "chronomancer" && A.has(p, 1)
            ? 0.5
            : p.cls === "loki" &&
                A.has(p, 3) &&
                saved.targets.some((o) => A.stacks(p, o) >= 3)
              ? 0.5
              : 0.45;
      later(ctx, 1, () => {
        for (const entry of saved.hits)
          if (
            valid(ctx, entry.target) &&
            (!entry.point || dist(entry.target, entry.point) <= 0.8) &&
            A.visible(ctx.inst, saved.origin, entry.target)
          )
            hit(
              {
                ...saved.ctx,
                indirect: true,
                hitSet: new Set(),
                marked: new Set(),
                controlled: new Set(),
                dotted: new Set(),
                d: { type: "echo" },
                boost: 1,
              },
              entry.target,
              entry.coefficient * fraction,
              { indirect: true },
            );
      });
      break;
    }
    case "reload":
      p.res = CLASSES[p.cls].resource.max;
      if (p.cls === "marksman" && A.has(p, 1) && !ctx.hurt)
        p.atlasReloadCast = true;
      break;
    case "delayed":
      if (valid(ctx, tgt, ctx.range)) {
        hit(ctx, tgt);
        tgt.atlasDelayed ??= new Map();
        const key = p.id + ":" + sk.id;
        const token = { until: now() + 2 };
        tgt.atlasDelayed.set(key, token);
        later(ctx, 2, () => {
          if (tgt.atlasDelayed.get(key) !== token) return;
          tgt.atlasDelayed.delete(key);
          if (valid(ctx, tgt)) {
            hit(
              { ...ctx, indirect: true, d: { type: "delayed" } },
              tgt,
              d.delayedDamage,
              { indirect: true },
            );
            A.event(p, "delayed", { ctx, target: tgt });
          }
        });
      }
      break;
    default:
      throw Error("Unimplemented atlas delivery " + d.type);
  }
  if (sk.id === "C04-A05" && tgt) {
    const q = A.entities(p, tgt.x, tgt.y, 4, true)
      .filter((q) => q.kind === "p")
      .sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
    if (q) heal(ctx, q, 0.6);
  }
  if (sk.id === "C25-A39" && (ctx.totalConsumed || 0) >= 3) {
    const q = A.entities(p, p.x, p.y, 4, true).find(
      (q) => q !== p && q.kind === "p",
    );
    if (q) A.shield(p, q, p.st.matk * 0.5, 2, sk.id + ":extra");
  }
  gain(ctx, "success");
  A.event(p, "resolved", { ctx });
};

A.spawn = function (ctx) {
  const { p, d, sk } = ctx,
    group = d.type === "repairDrone" ? "follower" : d.group,
    count = d.type === "army" ? 5 : 1;
  let existing = (p.summons || []).filter(
    (s) => alive(s) && s.atlasGroup === group,
  );
  while (existing.length + count > d.cap) {
    const old = existing.shift();
    if (!old) break;
    old.atlasEnd = "replacement";
    W.killQuiet(old);
  }
  for (let i = 0; i < count; i++) {
    const s = W.spawnSummon(p, {
      name: sk.name,
      dur: d.duration,
      shape: ["clone", "decoy"].includes(d.type)
        ? "spirit"
        : d.type === "army"
          ? "knight"
          : d.group === "companion"
            ? "wolf"
            : "spirit",
      color: CLASSES[p.cls].color,
      sk,
      mult: d.damage || 0,
      element: sk.element,
      mag: CLASSES[p.cls].basis !== "P",
    });
    s.atlasGroup = group;
    s.atlasSpec = d;
    s.atlasCtx = ctx;
    s.atlasCreated = now();
    s.atlasEnd = null;
    s.atkReady = now() + d.interval;
    s.range = d.unitRange || 1.6;
    s.speed = ["turret", "mortar", "decoy"].includes(d.type) ? 0 : 4.6;
    const hpBonus =
      (p.cls === "necromancer" && A.has(p, 3) && d.type !== "army" ? 0.15 : 0) +
      (p.cls === "beastmaster" && A.has(p, 2) && group === "companion"
        ? 0.1
        : 0);
    s.maxHp = Math.round(p.maxHp * d.hp * (1 + hpBonus));
    s.hp = s.maxHp;
    s.atkFlat = A.power(p);
    if (d.type === "clone") s.atkReady = Infinity;
    if (d.type === "decoy")
      for (const o of A.entities(p, s.x, s.y, 6))
        if (o.kind === "m" && o.rank < 2) {
          o.target = s;
          o.tauntBy = s;
          o.tauntUntil = s.until;
        }
  }
  gain(ctx, "success");
};
A.unitTick = function (s, dt, t) {
  const p = s.owner,
    ctx = s.atlasCtx,
    d = s.atlasSpec;
  if (!ctx) return false;
  if (!alive(s)) return true;
  if (t >= s.until || !alive(p) || p.inst !== s.inst) {
    if (!s.atlasEnd) {
      s.atlasEnd = "expired";
      A.event(p, "unitExpire", { unit: s, ctx });
    }
    W.killQuiet(s);
    return true;
  }
  if (C.isHardCC(s)) return true;
  if (s.atlasGroup === "clone" || s.atlasGroup === "decoy") return true;
  if (d.type === "repairDrone") {
    if (t >= s.atkReady) {
      s.atkReady = t + 1;
      const q = (p.summons || [])
        .filter((q) => alive(q) && q.atlasGroup === "turret" && dist(s, q) <= 6)
        .sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
      if (q) C.heal(q, q.maxHp * 0.06, p);
    }
    if (dist(s, p) > 3) W.stepToward(s, p.x, p.y, dt, 0.4);
    return true;
  }
  let candidates = A.entities(p, s.x, s.y, d.unitRange || 8).filter((o) =>
    A.visible(s.inst, s, o),
  );
  if ((p.cls === "engineer" && A.has(p, 3)) || ctx.sk.id === "C15-A04")
    candidates.sort(
      (a, b) => A.stacks(p, b) - A.stacks(p, a) || dist(s, a) - dist(s, b),
    );
  let target = candidates[0];
  if (!target && !["turret", "mortar"].includes(d.type)) {
    const ot = p.atkTarget && s.inst.entities.get(p.atkTarget);
    target = alive(ot) && C.isEnemy(p, ot) && dist(s, ot) < 14 ? ot : null;
  }
  if (s.atlasGroup === "companion" && dist(p, s) > 14) {
    W.stepToward(s, p.x, p.y, dt, 0.4);
    return true;
  }
  if (target) {
    if (dist(s, target) > (d.unitRange || 1.6)) {
      if (s.speed)
        W.stepToward(s, target.x, target.y, dt, (d.unitRange || 1.6) * 0.8);
    } else if (t >= s.atkReady) {
      s.atkReady = t + (d.interval || 1);
      const unitCtx = {
        ...ctx,
        origin: { x: s.x, y: s.y },
        indirect: true,
        d: { type: "summon" },
        boost: ctx.boost,
        marked: new Set(),
        controlled: new Set(),
        dotted: new Set(),
        hitSet: new Set(),
      };
      if (d.type === "mortar") {
        const point = { x: target.x, y: target.y };
        fx(ctx, "prepare", {
          x: point.x,
          y: point.y,
          tx: point.x,
          ty: point.y,
          r: 2,
          type: "circle",
          d: 0.5,
        });
        later(ctx, 0.5, () => {
          if (alive(s))
            for (const o of A.entities(p, point.x, point.y, 2))
              hit(unitCtx, o, d.damage, { indirect: true });
        });
      } else {
        let mult = d.damage;
        if (s.atlasGroup === "turret") mult *= 1 + A.stacks(p, target) * 0.02;
        if (p.cls === "shadowdancer" && s.atlasGroup === "clone")
          mult *= 1 + A.stacks(p, target) * 0.03;
        hit(unitCtx, target, mult, { indirect: true });
        if (d.secondary) {
          const next = A.entities(p, target.x, target.y, d.chainRange).find(
            (o) => o !== target,
          );
          if (next) {
            fx(ctx, "link", {
              x: target.x,
              y: target.y,
              tx: next.x,
              ty: next.y,
              d: 0.2,
            });
            hit(unitCtx, next, d.secondary, { indirect: true });
          }
        }
      }
      A.event(p, "unitHit", { unit: s, target, ctx });
    }
  } else if (s.speed && dist(s, p) > 3) W.stepToward(s, p.x, p.y, dt, 0.4);
  return true;
};
A.blocked = function (ctx, from, to) {
  for (const q of ctx.inst.players)
    if (C.isEnemy(ctx.p, q))
      for (const wall of q.atlasFields || [])
        if (wall.kind === "wall" && wall.until > now() && wall.a) {
          const cross = (a, b, c) =>
            (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
          if (
            cross(from, to, wall.a) * cross(from, to, wall.b) <= 0 &&
            cross(wall.a, wall.b, from) * cross(wall.a, wall.b, to) <= 0
          )
            return true;
        }
  return !A.visible(ctx.inst, from, to);
};
A.tick = function (p, dt, t, sec) {
  p.atlasJoined ??= t;
  if (p.atlasChannel && t >= p.atlasChannel.until) p.atlasChannel = null;
  const before = p.atlasLastPosition;
  if (before && before.inst === p.inst) {
    const n = dist(before, p);
    if (n > 0 && n < 2) {
      p.atlasWalk = (p.atlasWalk || 0) + n;
      A.event(p, "move", { distance: n, skill: false });
    }
  }
  p.atlasLastPosition = { x: p.x, y: p.y, inst: p.inst };
  if (p.atlasGuard && p.atlasGuard.until <= t) {
    const g = p.atlasGuard;
    if (!g.ctx.hurt) gain(g.ctx, "unhurt");
    p.atlasGuard = null;
  }
  if (p.atlasStance && p.atlasStance.until <= t) {
    if (!p.atlasStance.ctx.hurt) gain(p.atlasStance.ctx, "unhurt");
    p.atlasStance = null;
  }
  if (p.atlasFirstStatus?.until <= t) p.atlasFirstStatus = null;
  if (p.atlasFirstMana?.until <= t) p.atlasFirstMana = null;
  for (const [id, r] of Object.entries(p.atlasRecasts || {}))
    if (r.until < t) delete p.atlasRecasts[id];
  for (const z of p.atlasFields || []) {
    if (z.inst !== p.inst) {
      z.until = 0;
      continue;
    }
    const ctx = z.ctx,
      d = ctx.d;
    if (z.until <= t) {
      if (!z.finished) {
        z.finished = true;
        if (!ctx.hurt) gain(ctx, "unhurt");
        A.event(p, "fieldExpire", { field: z, ctx });
        fx(ctx, "dissolve", {
          x: z.x,
          y: z.y,
          uid: ctx.sk.id + ":" + ctx.created,
        });
      }
      continue;
    }
    if (z.kind === "tether") {
      const o = ctx.tether?.target;
      if (!alive(o) || o.inst !== p.inst) {
        z.until = 0;
        continue;
      }
      fx(ctx, "link", { x: z.x, y: z.y, tx: o.x, ty: o.y, d: 0.12 });
      if (dist(z, o) > d.breakRange) {
        hit(ctx, o);
        z.until = 0;
      }
      continue;
    }
    if (z.kind === "orbit") {
      if (!z.fxAt || t - z.fxAt > 0.1) {
        z.fxAt = t;
        fx(ctx, "persist", {
          x: p.x,
          y: p.y,
          tx: p.x,
          ty: p.y,
          r: z.r,
          d: 0.2,
          uid: ctx.sk.id + ":" + ctx.created,
        });
      }
      for (let i = 0; i < 3; i++)
        if (z.orbs[i]) {
          const a = (t - z.at) * 3 + (i * Math.PI * 2) / 3,
            at = { x: p.x + Math.cos(a) * 2, y: p.y + Math.sin(a) * 2 };
          const o = A.entities(p, at.x, at.y, 0.6)[0];
          if (o) {
            hit(ctx, o);
            z.orbs[i] = false;
            z.orbitTargets.add(o.id);
          }
        }
      if (!z.orbs.some(Boolean)) {
        z.until = 0;
        if (
          z.orbitTargets.size === 3 &&
          p.cls === "starhunter" &&
          A.proc(p, 2, 8)
        )
          p.sp = Math.min(p.maxSp, p.sp + 8);
      }
      continue;
    }
    if (z.kind === "slowOrb") {
      if (!z.fxAt || t - z.fxAt > 0.1) {
        z.fxAt = t;
        fx(ctx, "persist", {
          x: z.x,
          y: z.y,
          tx: z.x,
          ty: z.y,
          r: z.r,
          d: 0.2,
          uid: ctx.sk.id + ":" + ctx.created,
        });
      }
      const nx = z.x + Math.cos(z.direction) * d.speed * dt,
        ny = z.y + Math.sin(z.direction) * d.speed * dt;
      if (
        !A.visible(p.inst, z, { x: nx, y: ny }) ||
        dist(ctx.origin, { x: nx, y: ny }) > d.length
      ) {
        z.until = 0;
        continue;
      }
      z.x = nx;
      z.y = ny;
      for (const o of A.entities(p, z.x, z.y, z.r))
        if ((z.hitTimes.get(o.id) || 0) <= t) {
          z.hitTimes.set(o.id, t + 1);
          hit(ctx, o);
        }
      continue;
    }
    if (z.kind === "trap" || z.kind === "seed") {
      const enemy = A.entities(p, z.x, z.y, z.r)[0],
        friend =
          z.kind === "seed"
            ? [p, ...A.entities(p, z.x, z.y, z.r, true)].filter(
                (q) => alive(q) && dist(q, z) <= z.r && q.kind === "p",
              )[0]
            : null;
      const first = enemy || friend;
      if (first) {
        z.until = 0;
        A.event(p, "trapTrigger", { field: z, ctx, target: first });
        if (enemy)
          hit(
            ctx,
            enemy,
            d.damage *
              (p.cls === "ranger" && A.has(p, 1) && t - z.at > 2
                ? 1.12
                : p.cls === "druid" && A.has(p, 2) && t - z.at > 3
                  ? 1.1
                  : 1),
          );
        else
          heal(
            ctx,
            friend,
            d.heal *
              (p.cls === "druid" && A.has(p, 2) && t - z.at > 3 ? 1.1 : 1),
            true,
          );
      }
      continue;
    }
    if (t >= z.next) {
      z.next = t + (d.interval || 1);
      if (["zone", "domain", "slowZone"].includes(z.kind)) {
        if (ctx.sk.id === "C03-A30" && dist(p, z) > z.r) {
          z.until = 0;
          continue;
        }
        const enemies = A.entities(p, z.x, z.y, z.r);
        for (const o of enemies) {
          if (d.damage) hit({ ...ctx, indirect: true, persistent: true }, o);
          gain(ctx, "hit");
          if (skEffect(ctx) && !ctx.marked.has(o.id)) {
            A.addStatus(p, o, skEffect(ctx));
            ctx.marked.add(o.id);
          }
          if (d.control) A.control(p, o, d.control);
        }
        if (z.kind === "domain")
          for (const q of [
            p,
            ...A.entities(p, z.x, z.y, z.r, true).filter((q) => q !== p),
          ])
            if (q.kind === "p" && dist(q, z) <= z.r)
              C.addBuff(q, "atlas-domain", { dmgReduce: 15 }, 1.1, ctx.sk.name);
      }
      if (["healingZone", "sanctuary"].includes(z.kind))
        for (const q of [
          p,
          ...A.entities(p, z.x, z.y, z.r, true).filter((q) => q !== p),
        ])
          if (dist(q, z) <= z.r) {
            heal(ctx, q, d.heal, true);
            if (z.kind === "sanctuary") {
              z.cleansed ??= new Set();
              if (!z.cleansed.has(q.id)) {
                A.cleanse(p, q, 1, ctx);
                z.cleansed.add(q.id);
              }
            }
          }
      if (z.kind === "regenBuff") C.heal(p, p.maxHp * 0.02, p, true);
    }
  }
  p.atlasFields = (p.atlasFields || []).filter((z) => !z.finished);
  if (sec) A.event(p, "second", {});
};
A.secondEntity = function (e, t) {
  for (const [k, v] of e.tags || [])
    if (v.atlas && v.until <= t) e.tags.delete(k);
  for (const [key, s] of e.atlasShields || [])
    if (s.until <= t) {
      e.shield = Math.max(0, e.shield - s.amount);
      e.atlasShields.delete(key);
    }
  for (const [key, s] of e.atlasStatuses || []) {
    if (s.until <= t) {
      e.atlasStatuses.delete(key);
      continue;
    }
    if (s.next <= t) {
      s.next = t + 1;
      if (s.cls === "pyromancer" || s.cls === "assassin") {
        const factor = s.cls === "pyromancer" ? 0.05 : 0.04;
        C.dealDamage(s.src, e, {
          power: A.power(s.src) * factor * s.stacks,
          mag: s.cls === "pyromancer",
          kind: "dot",
          el: s.cls === "pyromancer" ? "fire" : "poison",
          atlas: true,
          indirect: true,
        });
      }
    }
  }
  for (const [key, d] of e.atlasDots || []) {
    if (d.until < t) {
      e.atlasDots.delete(key);
      continue;
    }
    if (d.next <= t && d.p.inst === e.inst) {
      d.next = t + 1;
      let mult = d.damage;
      if (d.p.cls === "berserker") mult *= 1 + A.stacks(d.p, e) * 0.03;
      const was = alive(e);
      C.dealDamage(d.p, e, {
        power: A.power(d.p) * mult,
        mag: CLASSES[d.p.cls].basis !== "P",
        kind: "dot",
        atlas: true,
        indirect: true,
        sk: d.sk,
      });
      if (was && !alive(e))
        A.event(d.p, "kill", {
          target: e,
          kind: "dot",
          indirect: true,
          stacks: A.stacks(d.p, e),
          ctx: { sk: d.sk },
        });
    }
  }
};
A.beforeDamage = function (src, tgt, amount, o) {
  let n = amount;
  const p = C.ownerP(src),
    t = now();
  if (tgt.atlasGuard?.until > t && o.kind !== "dot") {
    const g = tgt.atlasGuard,
      a = Math.atan2(src.y - tgt.y, src.x - tgt.x),
      front =
        Math.abs(Math.atan2(Math.sin(a - g.angle), Math.cos(a - g.angle))) <=
        Math.PI / 2;
    if (front) {
      n *= 1 - g.reduction;
      tgt.atlasDefenseUntil = t + 2;
      if (!g.used && g.ctx.d.type === "parry") {
        g.used = true;
        if (alive(src) && C.isEnemy(tgt, src)) {
          hit(g.ctx, src, g.ctx.d.damage);
          gain(g.ctx, "condition");
          A.event(tgt, "parry", { ctx: g.ctx, source: src });
        }
      }
    }
  }
  if (tgt.kind === "p") {
    if (A.stacks(tgt, src) && tgt.cls === "guardian")
      n *= 1 - A.stacks(tgt, src) * 0.02;
    if (p?.atlasTaunt?.until > t && p.atlasTaunt.by !== tgt.id) n *= 0.85;
    if (
      tgt.cls === "druid" &&
      A.has(tgt, 4) &&
      tgt.atlasMorph?.until > t &&
      !o.sk?.atlas?.delivery?.speed
    )
      n *= 0.92;
    if (
      tgt.cls === "stormcaller" &&
      A.has(tgt, 5) &&
      o.sk?.atlas?.delivery?.speed &&
      (tgt.atlasFields || []).some((z) => z.until > t && dist(tgt, z) <= 1.5)
    )
      n *= 0.9;
    if (
      tgt.cls === "engineer" &&
      A.has(tgt, 4) &&
      (tgt.summons || []).some(
        (s) => alive(s) && s.atlasGroup === "turret" && dist(tgt, s) <= 4,
      )
    )
      n *= 0.94;
    if (
      tgt.cls === "spellblade" &&
      A.has(tgt, 4) &&
      o.mag &&
      A.stacks(tgt, src) >= 5
    )
      n *= 0.92;
  }
  if (tgt.kind === "s" && tgt.owner) {
    const owner = tgt.owner;
    if (
      owner.cls === "demon" &&
      tgt.atlasGroup !== "army" &&
      A.has(owner, 2) &&
      dist(tgt, owner) <= 6
    )
      n *= 0.9;
    if (src && A.stacks(owner, src)) {
      if (owner.cls === "demon") n *= 1 - A.stacks(owner, src) * 0.03;
      if (
        owner.cls === "necromancer" &&
        A.has(owner, 5) &&
        A.stacks(owner, src) >= 5
      )
        n *= 0.9;
    }
    if (owner.cls === "shadowdancer" && A.has(owner, 1) && o.sk?.radius)
      n *= 0.85;
  }
  // A link is a single hop. Redirected damage never re-enters the routing pass.
  if (tgt.kind === "p" && !o.redirected) {
    for (const q of tgt.inst.players)
      if (
        q !== tgt &&
        alive(q) &&
        q.atlasInterpose?.target === tgt &&
        q.atlasInterpose.until > t &&
        dist(q, tgt) <= 10
      ) {
        const share = n * 0.35;
        n -= share;
        C.dealDamage(src, q, {
          flat: share,
          kind: "redirect",
          redirected: true,
          atlas: true,
          indirect: true,
        });
        A.event(q, "redirect", { target: tgt, got: share });
        break;
      }
  }
  return Math.max(0, n);
};
A.afterDamage = function (src, tgt, got, o, shieldBefore, hpBefore) {
  const p = C.ownerP(src),
    t = now();
  if (got > 0) {
    if (tgt.casting?.atlas) tgt.casting.atlas.hurt = true;
    if (tgt.atlasGuard) tgt.atlasGuard.ctx.hurt = true;
    if (tgt.atlasStance) tgt.atlasStance.ctx.hurt = true;
    for (const z of tgt.atlasFields || []) z.ctx.hurt = true;
    tgt.atlasLastEnemyHurt = t;
    if (tgt.kind === "p") {
      tgt.lastHit = t;
      A.event(tgt, "hurt", { source: src, got, ctx: o });
    }
    if (tgt.stealthUntil > t) {
      tgt.stealthUntil = 0;
      if (tgt.kind === "p") A.event(tgt, "stealthBroken", {});
    }
  }
  if (shieldBefore > 0 && (tgt.shield || 0) <= 0 && tgt.atlasShields) {
    for (const [key, s] of tgt.atlasShields)
      A.event(s.src, "shieldBreak", { target: tgt, got: shieldBefore, key });
    tgt.atlasShields.clear();
  }
  if (tgt.atlasShields && shieldBefore > (tgt.shield || 0)) {
    let left = shieldBefore - (tgt.shield || 0);
    for (const [k, s] of tgt.atlasShields) {
      const used = Math.min(s.amount, left);
      s.amount -= used;
      left -= used;
      if (s.amount <= 0) tgt.atlasShields.delete(k);
      if (left <= 0) break;
    }
  }
  if (p && shieldBefore > (tgt.shield || 0))
    A.event(p, "shieldDamage", {
      got: shieldBefore - (tgt.shield || 0),
      target: tgt,
    });
  if (
    tgt.kind === "s" &&
    tgt.atlasCtx &&
    hpBefore > 0 &&
    !alive(tgt) &&
    !tgt.atlasEnd
  ) {
    tgt.atlasEnd = "destroyed";
    A.event(tgt.owner, "unitDestroyed", { unit: tgt, source: src });
    if (tgt.atlasGroup === "decoy") {
      const ctx = tgt.atlasCtx;
      for (const e of A.entities(tgt.owner, tgt.x, tgt.y, 2))
        hit({ ...ctx, indirect: true }, e, 1.4, { indirect: true });
    }
  }
  if (o.kind === "basic" && p && got > 0) {
    if (p.atlasStance?.until > t) {
      const stance = p.atlasStance;
      hit(stance.ctx, tgt, stance.ctx.d.damage);
      gain(stance.ctx, "hit");
      if (!stance.ctx.hurt) gain(stance.ctx, "unhurt");
      p.atlasStance = null;
    }
    if (p.atlasMorph?.until > t)
      for (const e of A.entities(p, p.x, p.y, 2))
        if (e !== tgt)
          hit({ ...p.atlasMorph.ctx, indirect: true }, e, 1.1, {
            indirect: true,
          });
    for (const s of p.summons || [])
      if (alive(s) && s.atlasGroup === "clone" && A.visible(p.inst, s, tgt)) {
        hit(
          {
            ...s.atlasCtx,
            origin: { x: s.x, y: s.y },
            indirect: true,
            d: { type: "clone" },
          },
          tgt,
          0.35 * (p.cls === "shadowdancer" ? 1 + A.stacks(p, tgt) * 0.03 : 1),
          { indirect: true },
        );
        if (
          p.cls === "shadowdancer" &&
          A.stacks(p, tgt) >= 5 &&
          A.proc(p, 5, 1)
        )
          C.heal(s, s.maxHp * 0.01, p);
      }
    if (p.atlasTransform?.until > t) gain(p.atlasTransform.ctx, "hit");
  }
};
A.damageBonus = function (ctx, o) {
  const p = ctx.p,
    d = ctx.d,
    n = A.stacks(p, o),
    t = now(),
    melee = ctx.range <= 4 && !d.speed;
  let b = 0;
  const prior = ctx.previous && SKILLS[ctx.previous],
    last = p.atlasPriorCast;
  if (
    p.cls === "blademaster" &&
    A.has(p, 1) &&
    melee &&
    prior &&
    prior.id !== ctx.sk.id &&
    last &&
    t - last.at <= 3
  )
    b += 0.06;
  if (
    p.cls === "pyromancer" &&
    A.has(p, 1) &&
    ctx.sk.name === "Cinder Dart" &&
    n >= 5
  )
    b += 0.1;
  if (
    p.cls === "pyromancer" &&
    A.has(p, 5) &&
    d.radius &&
    A.entities(p, ctx.aim.x, ctx.aim.y, d.radius).length === 1
  )
    b += 0.1;
  if (
    p.cls === "cryomancer" &&
    A.has(p, 1) &&
    ctx.sk.name === "Shatter Verdict" &&
    n >= 5
  )
    b += 0.12;
  if (
    p.cls === "marksman" &&
    A.has(p, 2) &&
    ctx.sk.kind !== "ult" &&
    d.speed &&
    !d.radius &&
    dist(p, o) > 10
  )
    b += 0.08;
  if (
    p.cls === "lightbringer" &&
    o.hp >= o.maxHp &&
    A.proc(p, 1, 15, ":" + o.id)
  )
    b += 0.1;
  if (
    p.cls === "reaper" &&
    A.has(p, 5) &&
    o.hp / o.maxHp < 0.35 &&
    A.behind(p, o)
  )
    b += 0.08;
  if (
    p.cls === "jester" &&
    ctx.sk.name === "Card Flick" &&
    A.has(p, 1) &&
    ctx.deckIndex === 0
  )
    b += 0.08;
  if (p.cls === "warlock" && A.has(p, 2) && d.type === "drain") b += 0.06;
  if (p.cls === "deity" && A.has(p, 2) && A.healSlots(p) >= 2) b -= 0.03;
  if (p.atlasSwapBonus?.until > t) {
    b += 0.1;
    p.atlasSwapBonus = null;
  }
  return b;
};
A.staggerBonus = function (ctx, o) {
  const p = ctx.p,
    d = ctx.d;
  let b = 1;
  if (
    p.cls === "blademaster" &&
    A.has(p, 5) &&
    dist(p, o) >= 1.5 &&
    dist(p, o) <= 3
  )
    b += 0.1;
  if (
    p.cls === "berserker" &&
    A.has(p, 4) &&
    ctx.preRes >= 70 &&
    ctx.sk.cast >= 0.7
  )
    b += 0.15;
  if (
    p.cls === "stormcaller" &&
    A.has(p, 2) &&
    ctx.sk.needRes &&
    A.stacks(p, o) >= 5
  )
    b += 0.15;
  if (p.cls === "assassin" && A.has(p, 1) && A.behind(p, o)) b += 0.12;
  if (
    p.cls === "ranger" &&
    A.has(p, 3) &&
    o.atlasLeftTrap?.owner === p.id &&
    now() - o.atlasLeftTrap.at <= 2
  )
    b += 0.15;
  if (p.cls === "chronomancer" && A.has(p, 4) && d.type === "delayed") {
    const status = A.status(p, o);
    if (status && now() - status.since >= 4 && !status.futureUsed) {
      status.futureUsed = true;
      b += 0.15;
    }
  }
  if (
    p.cls === "starhunter" &&
    A.has(p, 3) &&
    now() - (p.movedAt || 0) >= 1 &&
    ctx.sk.kind !== "ult"
  )
    b += 0.15;
  if (
    p.cls === "darkknight" &&
    A.has(p, 2) &&
    (d.pull || d.push) &&
    o.rank >= 2
  )
    b += 0.2;
  if (
    p.cls === "demon" &&
    A.has(p, 5) &&
    d.control?.tag === "fear" &&
    o.rank >= 2
  )
    b += 0.2;
  if (
    p.cls === "jester" &&
    ctx.sk.name === "Card Flick" &&
    A.has(p, 1) &&
    ctx.deckIndex === 1
  )
    b += 0.15;
  return b;
};
A.healSlots = (p) =>
  new Set(
    (p.char.hotbar || []).filter((id) => SKILLS[id]?.atlas?.delivery.heal),
  ).size;

const byName = (p, name) =>
  Object.values(SKILLS).find((s) => s.cls === p.cls && s.name === name)?.id;
function reduce(p, name, seconds) {
  const id = byName(p, name);
  if (id && p.cds[id] > now()) {
    p.cds[id] = Math.max(now(), p.cds[id] - seconds);
    send(p, { t: "cd", id, d: Math.max(0, p.cds[id] - now()) });
  }
}
const mana = (p, n) => {
  p.sp = Math.min(p.maxSp, p.sp + n);
};
function ownField(p, type, name) {
  return (p.atlasFields || []).find(
    (z) =>
      z.until > now() &&
      (!type || z.kind === type) &&
      (!name || z.ctx.sk.name === name) &&
      dist(p, z) <= z.r,
  );
}
A.event = function (p, event, data) {
  if (!p?.char || !CLASSES[p.cls]) return;
  const t = now(),
    { ctx, target: o, unit: s, got = 0, stacks = 0 } = data,
    sk = ctx?.sk,
    d = ctx?.d || sk?.atlas?.delivery || {},
    name = sk?.name || "",
    pass = (i) => A.has(p, i),
    proc = (i, cd, key) => A.proc(p, i, cd, key),
    gain = (n) => A.resource(p, n, "passive"),
    shield = (n, duration = 2, key = "passive") =>
      A.shield(p, p, p.maxHp * n, duration, prefix(p) + ":" + key),
    healHp = (n) => C.heal(p, p.maxHp * n, p, true);
  if (event === "cast") {
    p.atlasPriorCast = p.atlasCurrentCast;
    p.atlasCurrentCast = { at: t, id: sk.id, type: d.type };
    if (p.stealthUntil > t && d.type !== "stealth") p.stealthUntil = 0;
    if (sk.needRes)
      p.atlasLastSpend = { at: t, hp: p.hp, target: ctx.tgt, ctx };
  }
  switch (p.cls) {
    case "blademaster":
      if (event === "parry" && proc(2, 8)) reduce(p, "Returning Edge", 2);
      if (
        event === "kill" &&
        !data.indirect &&
        sk?.needRes &&
        o?.owner !== p &&
        proc(4, 6)
      )
        mana(p, 8);
      break;
    case "guardian":
      if (event === "hurt" && got > 0) {
        const src = data.source,
          a = src ? Math.atan2(src.y - p.y, src.x - p.x) : 0;
        if (
          Math.abs(Math.atan2(Math.sin(a - p.dir), Math.cos(a - p.dir))) <=
            Math.PI / 2 &&
          proc(1, 1)
        )
          gain(5);
        if (p.hp < p.maxHp * 0.3 && proc(5, 45)) shield(0.08, 3);
      }
      if (event === "redirect" && got > 0 && proc(2, 3)) healHp(0.01);
      if (event === "shieldBreak" && proc(3, 6)) mana(p, 6);
      if (event === "second")
        p.atlasDisplaceRes =
          pass(4) &&
          A.entities(p, p.x, p.y, 3, true).filter(
            (q) => q !== p && q.kind === "p",
          ).length >= 2
            ? 0.2
            : 0;
      break;
    case "berserker":
      if (event === "hurt" && got > 0) {
        p.atlasPain = (p.atlasPain || 0) + got;
        if (p.atlasPain >= p.maxHp * 0.05 && proc(1, 2)) {
          gain(5);
          p.atlasPain = 0;
        }
      }
      if (
        event === "kill" &&
        data.kind === "dot" &&
        name &&
        sk.atlas.delivery.dot?.tag === "bleed" &&
        proc(3, 4)
      )
        healHp(0.02);
      break;
    case "paladin":
      if (event === "resolved" && sk.kind === "attack" && pass(1))
        p.atlasHealBonus = t + 4;
      if (
        event === "heal" &&
        data.before < o.maxHp * 0.5 &&
        got > 0 &&
        o.kind === "p" &&
        proc(2, 4)
      )
        gain(6);
      if (event === "hit" && stacks >= 5 && proc(3, 3)) mana(p, 4);
      if (event === "shield" && o !== p && dist(p, o) <= 6 && pass(4))
        C.addBuff(p, "oath:slow", { slowRes: 15 }, 3, "Shared Conviction");
      if (event === "revive" && name === "Rite of Return" && pass(5))
        C.addBuff(o, "vigil", { dmgReduce: 15 }, 3, "Vigil at Dawn");
      break;
    case "pyromancer":
      if (event === "second" && pass(2) && t - (p.atlasLastCast || 0) >= 3)
        p.res = Math.max(0, p.res - 10);
      if (event === "kill" && stacks && proc(3, 2)) {
        const q = A.entities(p, o.x, o.y, 4).find((q) => q !== o);
        if (q) A.addStatus(p, q);
      }
      if (event === "cast" && sk.needRes >= 30 && proc(4, 6))
        reduce(p, "Ash Step", 1);
      break;
    case "cryomancer":
      if (event === "second") {
        const f = ownField(p, "zone");
        if (f) {
          p.atlasFrostSince ??= t;
          if (t - p.atlasFrostSince >= 2 && proc(2, 4)) gain(5);
        } else p.atlasFrostSince = null;
      }
      if (event === "fieldExpire" && data.field.kind === "wall" && proc(3, 12))
        shield(0.05, 3);
      if (event === "statusCleansed" && proc(5, 10, ":" + o.id))
        ((o.atlasWinter ??= new Set()), o.atlasWinter.add(p.id));
      break;
    case "stormcaller":
      if (event === "move" && !data.skill && p.atlasLastCast) {
        p.atlasCircuit = (p.atlasCircuit || 0) + data.distance;
        if (p.atlasCircuit >= 6 && proc(1, 3)) {
          gain(5);
          p.atlasCircuit = 0;
        }
      }
      if (event === "movementSkill" && data.distance > 0 && pass(4))
        p.atlasNextCast = { until: t + 3 };
      break;
    case "necromancer":
      if (event === "nearDeath" && !o.owner && dist(p, o) <= 10 && proc(1, 3))
        gain(1);
      if (event === "hit" && o.rank >= 2) {
        p.atlasBossCount = (p.atlasBossCount || 0) + 1;
        if (p.atlasBossCount >= 5 && proc(2, 4)) {
          p.atlasBossCount = 0;
          gain(1);
        }
      }
      if (event === "sacrifice" && t - s.atlasCreated >= 3 && proc(4, 6))
        mana(p, 8);
      break;
    case "cleric":
      if (event === "heal") {
        if (got >= o.maxHp * 0.05 && proc(2, 3)) gain(4);
        if (data.overheal > 0 && proc(3, 8, ":" + o.id))
          A.shield(
            p,
            o,
            Math.min(data.overheal, o.maxHp * 0.04),
            3,
            "No Wasted Light",
          );
      }
      if (
        event === "cleanse" &&
        o !== p &&
        ["stun", "root", "fear", "silence", "knockdown", "airborne"].includes(
          data.tag,
        ) &&
        proc(5, 8)
      )
        reduce(p, "Gentle Hand", 2);
      break;
    case "druid":
      if (event === "cast" && pass(1)) {
        const mode = d.heal ? "heal" : d.damage ? "damage" : null;
        if (
          mode &&
          p.atlasSeason &&
          mode !== p.atlasSeason.mode &&
          t - p.atlasSeason.at <= 4 &&
          proc(1, 3)
        )
          gain(4);
        if (mode) p.atlasSeason = { mode, at: t };
      }
      if (event === "fieldExpire" && data.field.kind === "seed" && proc(3, 5))
        mana(p, 5);
      if (event === "unitExpire" && proc(5, 12)) {
        const fake = {
          ...s.atlasCtx,
          origin: { x: s.x, y: s.y },
          aim: { x: s.x, y: s.y },
          d: {
            type: "seed",
            range: 0,
            radius: 1,
            duration: 6,
            damage: 1.7,
            heal: 0.9,
          },
          indirect: true,
        };
        field(fake);
      }
      break;
    case "assassin":
      if (
        event === "resolved" &&
        name === "Venom Reclaim" &&
        ctx.preStacks >= 5 &&
        proc(2, 6)
      )
        mana(p, 6);
      if (event === "stealthBroken" && proc(3, 12))
        C.addBuff(
          p,
          "conceal:broken",
          { dmgReduce: 10 },
          1,
          "Broken Concealment",
        );
      if (event === "kill" && o.atlasMarks?.get(p.id)?.until > t && proc(4, 5))
        gain(1);
      if (
        event === "move" &&
        p.atlasLastSpend?.target &&
        t - p.atlasLastSpend.at <= 2 &&
        dist(p, p.atlasLastSpend.target) >= 3 &&
        proc(5, 8)
      )
        reduce(p, "Escape Cut", 2);
      break;
    case "shadowdancer":
      if (event === "swap" && pass(2)) p.atlasSwapBonus = { until: t + 2 };
      if (event === "unitDestroyed" && s.atlasGroup === "clone" && proc(3, 6))
        gain(8);
      if (event === "movementSkill" && data.distance > 0) {
        if (
          p.atlasLastMove &&
          p.atlasLastMove.name !== name &&
          t - p.atlasLastMove.at <= 4 &&
          proc(4, 8)
        )
          mana(p, 6);
        p.atlasLastMove = { name, at: t };
      }
      break;
    case "ranger":
      if (event === "movementSkill" && data.distance > 0 && pass(2))
        p.atlasNextMana = { value: 0.2, until: t + 3, projectile: true };
      if (event === "hit" && dist(p, o) > 8 && proc(5, 3)) gain(3);
      if (event === "trapTrigger")
        data.target.atlasLeftTrap = { at: t, owner: p.id };
      break;
    case "marksman":
      if (event === "hit" && stacks >= 5 && proc(3, 5))
        reduce(p, "Retreat Fire", 1);
      if (event === "kill" && !data.indirect && sk?.needRes && proc(4, 8))
        gain(1);
      break;
    case "engineer":
      if (event === "unitExpire" && s.atlasGroup === "turret" && pass(1))
        gain(10);
      if (event === "hit" && proc(2, 2)) {
        const q = (p.summons || [])
          .filter((s) => alive(s) && s.atlasGroup === "turret")
          .sort((a, b) => dist(p, a) - dist(p, b))[0];
        if (q) C.heal(q, q.maxHp * 0.03, p);
      }
      if (event === "unitDestroyed" && s.atlasGroup === "turret" && proc(5, 8))
        reduce(p, "Cable Hook", 2);
      break;
    case "monk":
      if (event === "cast") {
        const limb = /Kick|Heel/.test(name) ? "kick" : d.damage ? "fist" : null;
        if (
          limb &&
          p.atlasLimb &&
          p.atlasLimb.kind !== limb &&
          t - p.atlasLimb.at <= 3 &&
          proc(1, 3)
        )
          gain(4);
        if (limb) p.atlasLimb = { kind: limb, at: t };
        if (
          ["parry", "guard"].includes(d.type) &&
          pass(4) &&
          t - (p.movedAt || 0) >= 1
        )
          ctx.d = { ...d, duration: Math.min(2, d.duration + 0.1) };
        if (sk.needRes >= 30 && pass(5)) {
          const hp = p.hp;
          later(ctx, 2, () => {
            if (p.hp >= hp && proc(5, 8)) healHp(0.02);
          });
        }
      }
      if (
        event === "hit" &&
        stacks >= 5 &&
        ["heavy", "chargedLine", "shieldbreak", "execute"].includes(d.type) &&
        proc(2, 5)
      )
        reduce(p, "Opening Palm", 1);
      if (event === "parry" && proc(3, 4)) mana(p, 5);
      break;
    case "spellblade":
      if (event === "cast") {
        const mode = d.speed
          ? "projectile"
          : ctx.range <= 4 && d.damage
            ? "melee"
            : null;
        if (
          mode &&
          p.atlasWeave &&
          p.atlasWeave.mode !== mode &&
          t - p.atlasWeave.at <= 3 &&
          proc(1, 4)
        )
          gain(1);
        if (mode) p.atlasWeave = { mode, at: t };
        if (
          d.speed &&
          sk.kind !== "ult" &&
          p.atlasDefenseUntil > t - 1 &&
          pass(5)
        ) {
          ctx.range += 2;
          ctx.d = { ...d, length: (d.length || ctx.range) + 2 };
        }
      }
      if (event === "resolved" && sk.needRes && pass(2)) {
        later(ctx, Math.max(1, d.duration || 0), () => {
          if (ctx.ledger.hits === 0 && proc(2, 10)) gain(1);
        });
      }
      if (event === "hit" && ctx.range <= 4 && proc(3, 2))
        reduce(p, "Arc Needle", 0.5);
      break;
    case "beastmaster":
      if (event === "hit") {
        p.atlasPlayerHit = { id: o.id, at: t };
        if (
          p.atlasPetHit?.id === o.id &&
          t - p.atlasPetHit.at <= 2 &&
          proc(1, 3)
        )
          gain(5);
      }
      if (event === "unitHit") {
        p.atlasPetHit = { id: o.id, at: t };
        if (
          p.atlasPlayerHit?.id === o.id &&
          t - p.atlasPlayerHit.at <= 2 &&
          proc(1, 3)
        )
          gain(5);
      }
      if (
        event === "unitDestroyed" &&
        s.atlasGroup === "companion" &&
        proc(3, 20)
      ) {
        reduce(p, "Home Whistle", 3);
        for (const q of Object.values(SKILLS))
          if (q.cls === p.cls && q.atlas.delivery.group === "companion")
            reduce(p, q.name, 3);
      }
      if (event === "command" && A.stacks(p, o) >= 5 && proc(5, 5)) mana(p, 5);
      break;
    case "chronomancer":
      if (event === "delayed" && name === "Borrowed Impact" && proc(2, 4))
        gain(5);
      if (event === "rewind" && got >= p.maxHp * 0.05 && proc(3, 15))
        shield(0.03);

      if (event === "portalReturn" && pass(5))
        p.atlasNextMana = { value: 0.2, until: t + 3 };
      break;
    case "warlock":
      if (event === "hpPayment" && name === "Blood Signature" && proc(1, 8))
        shield(0.03);
      if (event === "unitHit" && A.stacks(p, o) >= 5 && proc(3, 3)) gain(4);
      if (event === "cast" && sk.needRes >= 35 && proc(4, 10))
        reduce(p, "Pact Passage", 2);
      break;
    case "starhunter":
      // Last-seen snapshots are emitted by world.sendSnapshots without updating through walls.
      break;
    case "darkknight":
      if (event === "displace" && proc(1, 3)) gain(5);
      if (event === "portalReturn" && proc(3, 10))
        C.addBuff(p, "return:anchor", { dmgReduce: 8 }, 2, "Return Anchor");
      if (event === "hit" && stacks >= 5 && dist(p, o) <= 2 && proc(4, 2))
        mana(p, 3);
      break;
    case "lightbringer":
      if (
        event === "status" &&
        data.stacks === 5 &&
        data.previous < 5 &&
        proc(2, 6, ":" + o.id)
      )
        gain(5);
      if (event === "hit" && d.radius && ctx.hitSet.size >= 3 && proc(3, 10))
        shield(0.03);
      if (event === "statusCleansed" && proc(4, 5)) mana(p, 5);
      if (
        event === "resolved" &&
        name === "Collect the Writ" &&
        ctx.tgt?.hp < ctx.tgt?.maxHp * 0.3 &&
        proc(5, 8)
      )
        healHp(0.03);
      break;
    case "shadowmancer":
      if (event === "dispel" && name === "Consume Favor" && proc(1, 8))
        shield(0.04, 3);
      if (event === "shieldDamage") {
        p.atlasEaten = (p.atlasEaten || 0) + got;
        if (p.atlasEaten >= p.maxHp * 0.05 && proc(2, 4)) {
          gain(5);
          p.atlasEaten = 0;
        }
      }
      if (event === "second" && pass(4)) {
        if (!A.entities(p, p.x, p.y, 8).length) {
          p.atlasUnfed ??= t;
          if (t - p.atlasUnfed >= 3) mana(p, 2);
        } else p.atlasUnfed = null;
      }
      if (event === "statusCleansed" && proc(5, 10, ":" + o.id))
        A.control(p, o, { tag: "slow", pct: 10, duration: 1 });
      break;
    case "seraph":
      if (
        event === "shieldBreak" &&
        SKILLS[data.key]?.name === "Wing Shell" &&
        proc(1, 8)
      )
        gain(1);
      if (event === "movementSkill" && data.distance > 0) {
        const q = A.entities(p, p.x, p.y, 3, true).find(
          (q) => q !== p && q.hp < q.maxHp * 0.4,
        );
        if (q && proc(2, 8)) C.heal(q, p.st.matk * 0.5, p);
      }
      if (event === "heal" && o !== p && got >= o.maxHp * 0.05 && proc(4, 5))
        C.addBuff(p, "quiet:wings", { slowRes: 20 }, 2, "Quiet Wings");
      if (event === "rescue" && name === "Rescue Flight" && proc(5, 10))
        reduce(p, "Wing Shell", 2);
      break;
    case "reaper":
      if (
        event === "nearDeath" &&
        stacks &&
        o.owner !== p &&
        dist(p, o) <= 10 &&
        proc(1, 4)
      )
        gain(1);
      if (event === "hit" && o.rank >= 2 && o.hp < o.maxHp * 0.35) {
        p.atlasReapCount = (p.atlasReapCount || 0) + 1;
        if (p.atlasReapCount >= 4 && proc(2, 5)) {
          gain(1);
          p.atlasReapCount = 0;
        }
      }
      if (
        event === "resolved" &&
        name === "Final Toll" &&
        alive(ctx.tgt) &&
        proc(3, 10)
      )
        C.addBuff(p, "premature:toll", { slowRes: 20 }, 2, "No Premature Toll");
      if (event === "kill" && !data.indirect && sk?.needRes && proc(4, 8))
        reduce(p, "Grave Recoil", 2);
      break;
    case "demon":
      if (event === "second" && pass(1) && Math.floor(t) % 2 === 0) {
        const f = ownField(p, "zone", "Infernal Court");
        if (f && A.entities(p, f.x, f.y, f.r).length) gain(3);
      }
      if (event === "statusCleansed" && proc(3, 5)) mana(p, 5);
      if (event === "unitDestroyed" && s.atlasGroup === "follower" && pass(4))
        p.atlasRoyal = { until: t + 4 };
      break;
    case "deity":
      if (
        event === "cast" &&
        (d.heal || d.shield || d.shieldHp) &&
        p.atlasLastAttack > t - 4 &&
        proc(1, 4)
      )
        gain(4);
      if (event === "cast" && d.damage) p.atlasLastAttack = t;
      if (event === "rescue" && o !== p && o.hp < o.maxHp * 0.3 && proc(4, 15))
        mana(p, 10);
      break;
    case "jester":
      if (event === "cast" && name === "Card Flick" && pass(1))
        p.atlasDeck = ((p.atlasDeck || 0) + 1) % 3;
      if (
        event === "hit" &&
        name === "Card Flick" &&
        ctx.deckIndex === 2 &&
        !ctx.ledger.deckMana &&
        pass(1)
      ) {
        mana(p, 3);
        ctx.ledger.deckMana = true;
      }
      if (
        event === "trapTrigger" &&
        name === "Surprise Box" &&
        t - data.field.at > 3 &&
        proc(2, 6)
      )
        p.atlasExtraGain = { value: 5, until: t + 3 };
      if (event === "unitDestroyed" && s.atlasGroup === "decoy" && proc(3, 8))
        reduce(p, "Backward Bow", 2);
      if (event === "hit" && d.radius && ctx.hitSet.size >= 2 && proc(4, 5))
        mana(p, 5);
      if (
        event === "resolved" &&
        name === "Final Punchline" &&
        (ctx.maxConsumed || 0) >= 5 &&
        proc(5, 10)
      )
        shield(0.03);
      break;
    case "loki":
      if (
        event === "unitDestroyed" &&
        s.atlasCtx.sk.name === "False King" &&
        proc(1, 6)
      )
        gain(6);
      if (event === "swap" && pass(2)) p.atlasCrossed = { until: t + 2 };
      if (
        event === "hit" &&
        p.atlasCrossed?.until > t &&
        A.behind(p, o) &&
        proc(2, 8)
      ) {
        mana(p, 6);
        p.atlasCrossed = null;
      }
      if (event === "fieldExpire" && name === "Masked Form" && pass(4))
        C.addBuff(p, "broken:mask", { slowRes: 20 }, 2, "Broken Mask");
      if (event === "stealthBroken" && proc(5, 12))
        reduce(p, "Secret Passage", 2);
      break;
  }
};
A.speedMultiplier = function (e) {
  let slow = 0;
  for (const s of e.atlasStatuses?.values() || [])
    if (s.until > now() && s.cls === "cryomancer")
      slow = Math.max(slow, s.stacks * 0.04);
  const tag = e.tags?.get("slow");
  if (tag?.atlas && tag.until > now())
    slow = Math.max(slow, (tag.pct || 30) / 100);
  let res = 0;
  for (const b of e.buffs?.values() || [])
    res = Math.max(res, b.mods.slowRes || 0);
  return Math.max(0.1, 1 - slow * (1 - res / 100));
};
A.serializeStatuses = (e) =>
  [...(e.atlasStatuses || [])]
    .filter(([, s]) => s.until > now())
    .map(([owner, s]) => ({
      owner,
      cls: s.cls,
      stacks: s.stacks,
      remaining: s.until - now(),
      name: CLASSES[s.cls].status.name,
    }));

A.testContext = context;

function skEffect(ctx) {
  return ctx.sk.atlas.effects.applyStatus;
}

A.expire = function (e, t) {
  let changed = false;
  for (const [k, b] of e.buffs || [])
    if (b.until <= t) {
      e.buffs.delete(k);
      changed = true;
    }
  if (changed && e.kind === "p") {
    e.buffsChanged = true;
    C.recalc(e);
  }
  for (const [k, v] of e.tags || [])
    if (v.atlas && v.until <= t) e.tags.delete(k);
  for (const [k, v] of e.atlasStatuses || [])
    if (v.until <= t) e.atlasStatuses.delete(k);
  for (const [k, v] of e.atlasShields || [])
    if (v.until <= t) {
      e.shield = Math.max(0, e.shield - v.amount);
      e.atlasShields.delete(k);
    }
};

// Cleanse real effects only. Boss-forced mechanics never enter these player-owned collections.
A.cleanse = function (p, target, maximum, ctx) {
  let removed = 0;
  for (const [key, effect] of target.tags)
    if (removed < maximum && !effect.boss && !effect.locked) {
      target.tags.delete(key);
      removed++;
      A.event(p, "cleanse", { target, tag: key, ctx });
    }
  for (const [key, effect] of target.atlasStatuses || [])
    if (removed < maximum) {
      target.atlasStatuses.delete(key);
      removed++;
      A.event(effect.src, "statusCleansed", { target, source: p, ctx });
    }
  for (const collection of [target.atlasDelayed, target.atlasMarks])
    for (const [key] of collection || [])
      if (removed < maximum) {
        collection.delete(key);
        removed++;
      }
  return removed;
};

A.threatDistance = function (monster, candidate, squaredDistance) {
  const guard = monster.atlasCover;
  if (
    monster.rank >= 2 ||
    !alive(guard) ||
    guard === candidate ||
    !A.stacks(guard, monster) ||
    !C.isAlly(guard, candidate)
  )
    return squaredDistance;
  const frontX = monster.x - guard.x,
    frontY = monster.y - guard.y;
  const behind =
    (candidate.x - guard.x) * frontX + (candidate.y - guard.y) * frontY < 0;
  return behind
    ? squaredDistance * (1 + (CONFIG.threatCoverPenalty || 0.1))
    : squaredDistance;
};
