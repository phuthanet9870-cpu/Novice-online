// Pure, versioned migration. Input is a character copy; never touches files or resets progression.
(function (root, factory) {
  if (typeof module === "object" && module.exports)
    module.exports = factory(require("./skills"));
  else root.NO_SKILL_MIGRATION = factory(root.NO_SKILLS);
})(typeof self !== "undefined" ? self : this, function (atlas) {
  "use strict";
  const VERSION = 1,
    { SKILLS, CONFIG } = atlas;
  // Reviewed functional correspondences. No ordinal or random replacement.
  const MAP = {
    blademaster_a02: "C01-A01",
    blademaster_a03: "C01-A11",
    blademaster_a06: "C01-A02",
    blademaster_a07: "C01-A06",
    blademaster_a08: "C01-A18",
    blademaster_a10: "C01-A09",
    blademaster_a18: "C01-A07",
    blademaster_a20: "C01-A17",
    blademaster_a25: "C01-A08",
    blademaster_u4: "C01-U03",
    blademaster_u5: "C01-U04",
    blademaster_b1: "C01-B01",
    blademaster_b2: "C01-B03",
    blademaster_b4: "C01-B02",
  };
  function allowedBar(ch, slots) {
    const counts = { attack: 0, ult: 0, buff: 0 },
      seen = new Set();
    return Array.from({ length: CONFIG.hotbarSlots }, (_, i) => {
      const v = slots[i];
      if (typeof v !== "string") return null;
      if (v.startsWith("item:")) return v;
      const sk = SKILLS[v];
      if (
        !sk ||
        sk.cls !== ch.cls ||
        !ch.skills?.[v] ||
        sk.kind === "passive" ||
        seen.has(v) ||
        counts[sk.kind] >= CONFIG.loadout[sk.kind]
      )
        return null;
      seen.add(v);
      counts[sk.kind]++;
      return v;
    });
  }
  function migrate(ch) {
    if (ch.skillAtlasVersion >= VERSION) return { changed: false, refund: 0 };
    const skills = {},
      log = {
        version: VERSION,
        refund: 0,
        mapped: [],
        unmatched: [],
        clearedSlots: [],
        oldKitVersion: ch.kitVer,
      };
    for (const [id, raw] of Object.entries(ch.skills || {})) {
      const lv = Math.max(0, Number(raw) || 0);
      if (!lv) continue;
      const target = SKILLS[id]?.cls === ch.cls ? id : MAP[id],
        sk = target && SKILLS[target],
        weight = /_u\d+$/.test(id) || sk?.kind === "ult" ? 2 : 1;
      if (sk && sk.cls === ch.cls) {
        const keep = skills[target] ? 0 : 1;
        skills[target] = 1;
        log.refund += (lv - keep) * weight;
        log.mapped.push({ from: id, to: target, levels: lv });
      } else {
        log.refund += lv * weight;
        log.unmatched.push(id);
      }
    }
    ch.skills = skills;
    ch.skillPts = Math.max(0, Number(ch.skillPts) || 0) + log.refund;
    const converted = (ch.hotbar || []).map((v, i) => {
      if (!v || v.startsWith("item:")) return v || null;
      const next = SKILLS[v] ? v : MAP[v];
      if (!next || !skills[next]) {
        log.clearedSlots.push(i);
        return null;
      }
      return next;
    });
    ch.hotbar = allowedBar(ch, converted);
    ch.skillPassives = [];
    for (const k of ["rotation", "rotPve", "rotPvp"])
      if (Array.isArray(ch.auto?.[k]))
        ch.auto[k] = ch.auto[k]
          .map((v) => ({ ...v, id: SKILLS[v.id] ? v.id : MAP[v.id] }))
          .filter((v) => v.id && skills[v.id]);
    ch.skillAtlasVersion = VERSION;
    ch.skillMigration = log;
    return { changed: true, ...log };
  }
  return { VERSION, MAP, migrate, allowedBar };
});
