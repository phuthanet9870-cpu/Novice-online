"use strict";
process.env.NO_DATA_DIR = require("fs").mkdtempSync("/tmp/novice-tests-");
const C = require("../server/combat"),
  W = require("../server/world"),
  I = require("../server/items"),
  A = require("../server/atlas"),
  S = require("../shared/skills");
W.rand = () => 0.5;
let time = 2000000000;
Date.now = () => Math.round(time * 1000);
A.clock = () => time;
function arena(cls = "blademaster") {
  const events = [],
    timers = [];
  const inst = {
    id: "test",
    mapId: "test",
    def: { kind: "field" },
    pvp: false,
    autoAllowed: true,
    map: { w: 128, h: 128, walk: new Uint8Array(128 * 128).fill(1) },
    entities: new Map(),
    players: new Set(),
    emit: (e) => events.push(e),
    moveTo(e, x, y) {
      e.x = x;
      e.y = y;
    },
    add(e) {
      e.inst = this;
      this.entities.set(e.id, e);
      if (e.kind === "p") this.players.add(e);
    },
    remove(e) {
      this.entities.delete(e.id);
      this.players.delete(e);
    },
    after(delay, fn) {
      timers.push({ at: time + delay, fn });
    },
    inRadius(x, y, r, fn) {
      for (const o of this.entities.values())
        if (Math.hypot(o.x - x, o.y - y) <= r) fn(o);
    },
    query(x, y, rx, ry, fn) {
      for (const o of this.entities.values())
        if (Math.abs(o.x - x) <= rx && Math.abs(o.y - y) <= ry) fn(o);
    },
  };
  const messages = [];
  function player(key, name) {
    const ch = I.newChar({ user: name }, name, key);
    ch.lv = 250;
    ch.skills = Object.fromEntries(
      Object.values(S.SKILLS)
        .filter((s) => s.cls === key)
        .map((s) => [s.id, 1]),
    );
    ch.skillPassives = [];
    const p = C.makePlayer(
      ch,
      { send: (m) => messages.push(m) },
      { user: name, gm: 0 },
    );
    p.x = 50;
    p.y = 50;
    p.hp = p.maxHp * 0.5;
    p.sp = 100;
    p.res = S.ATLAS_CLASSES[key].resource.max;
    p.st.crit = 0;
    p.st.dmgPct = 0;
    p.st.bossDmg = 0;
    p.st.lifesteal = 0;
    p.st.critDmg = 0;
    p.gear = {}; p.pfx = {}; p.st.cdr = 0; p.cdrBonus = 0;
    inst.add(p);
    return p;
  }
  const p = player(cls, "Smoke"),
    ally = player("cleric", "Friend");
  ally.x = 51;
  ally.y = 51;
  ally.char.allowAtlasRescue = true;
  const enemy = {
    id: W.nextEnt++,
    kind: "m",
    x: 52,
    y: 50,
    dir: Math.PI,
    hp: 1e8,
    maxHp: 1e8,
    def: 0,
    mdef: 0,
    lv: 1,
    rank: 0,
    tags: new Map(),
    dmgBy: new Map(),
    shield: 0,
    dead: false,
    stagger: 1000,
    staggerMax: 1000,
    brokenUntil: 0,
    size: 0.6,
    speed: 4,
  };
  inst.add(enemy);
  for (let i = 0; i < 4; i++)
    inst.add({
      ...enemy,
      id: W.nextEnt++,
      x: 53 + i * 0.5,
      y: 50 + i * 0.3,
      tags: new Map(),
      dmgBy: new Map(),
    });
  function step(seconds) {
    const end = time + seconds;
    while (time < end - 1e-7) {
      time = Math.min(end, time + 0.05);
      for (const entry of timers.filter((q) => q.at <= time)) {
        timers.splice(timers.indexOf(entry), 1);
        entry.fn();
      }
      for (const q of [p, ally]) {
        if (q.casting && time >= q.casting.until) {
          const cast = q.casting;
          q.casting = null;
          C.exec(
            q,
            cast.sk,
            1,
            cast.tgtId ? inst.entities.get(cast.tgtId) : null,
            cast.ax,
            cast.ay,
            cast.atlas,
          );
        }
        A.tick(q, 0.05, time, false);
      }
      for (const s of [...inst.entities.values()])
        if (s.kind === "s") A.unitTick(s, 0.05, time);
      if (Math.abs(time - Math.round(time)) < 0.026)
        for (const o of inst.entities.values()) A.secondEntity(o, time);
    }
  }
  function cast(id, options = {}) {
    const sk = S.SKILLS[id],
      d = sk.atlas.delivery;
    p.char.hotbar = [id];
    p.cds = {};
    p.atlasGcd = 0;
    p.casting = null;
    p.sp = 100;
    p.res = S.ATLAS_CLASSES[p.cls].resource.max;
    if (d.range === null) enemy.x = p.x + p.st.range * 0.8;
    let target = [
      "heal",
      "shield",
      "rescue",
      "interpose",
      "cleanse",
      "revive",
      "pairShield",
    ].includes(d.type)
      ? ally
      : enemy;
    if (options.target) target = options.target;
    if (d.type === "revive") {
      ally.dead = true;
      ally.hp = 0;
    }
    if (d.type === "riposte") p.atlasDefenseUntil = time + 2;
    if (d.type === "cleanse") ally.tags.set("stun", { until: time + 10 });
    if (d.type === "dispel") {
      ally.buffs.set("test", { mods: {}, until: time + 10 });
      inst.pvp = true;
      target = ally;
    }
    if (["command", "sacrifice", "recall", "swap"].includes(d.type)) {
      const id = S.CLASS_SKILLS[p.cls].find((id) =>
        ["summon", "clone", "decoy"].includes(S.SKILLS[id].atlas.delivery.type),
      );
      const fallback = {
        type: d.type === "swap" ? "clone" : "summon",
        duration: 8,
        hp: 0.25,
        damage: 0.55,
        interval: 1,
        unitRange: 8,
        cap: 2,
        group: d.type === "swap" ? "clone" : "follower",
      };
      const other = id
        ? S.SKILLS[id]
        : { ...sk, atlas: { ...sk.atlas, delivery: fallback } };
      const ctx = A.testContext(p, other, enemy, 52, 50);
      ctx.d = fallback;
      A.spawn(ctx);
      if (d.type === "swap") target = p.summons.at(-1);
    }
    if (d.type === "echo") {
      const original = Object.values(S.SKILLS).find(
        (q) => q.cls === p.cls && q.atlas.delivery.type === "single",
      );
      const ctx = A.testContext(p, original, enemy, 52, 50);
      p.atlasEcho = {
        origin: { x: 50, y: 50 },
        ctx,
        targets: [enemy],
        hits: [{ target: enemy, coefficient: 1.6 }],
      };
    }
    const result = C.useSkill(
      p,
      id,
      target.id,
      options.x ?? 52,
      options.y ?? 50,
    );
    return { result, target };
  }
  return {
    p,
    ally,
    enemy,
    inst,
    events,
    messages,
    step,
    cast,
    time: () => time,
  };
}
module.exports = { arena, C, W, I, A, S };
