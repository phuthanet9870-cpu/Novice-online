"use strict";
// Optional browser QA: uses externally available Playwright and Chromium; neither is a game dependency.
const fs = require("fs"),
  path = require("path"),
  os = require("os"),
  assert = require("assert/strict"),
  { spawn } = require("child_process");
(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "novice-browser-"));
  process.env.NO_DATA_DIR = dir;
  const db = require("../server/db").load(),
    I = require("../server/items"),
    { SKILLS } = require("../shared/skills");
  const account = db.createAccount("browserqa", "local-browser-test");
  const ch = I.newChar(account, "BrowserQA", "blademaster");
  ch.lv = 250;
  ch.skills = Object.fromEntries(
    Object.values(SKILLS)
      .filter((s) => s.cls === "blademaster")
      .map((s) => [s.id, 1]),
  );
  ch.skillPassives = ["C01-P01", "C01-P02", "C01-P05"];
  ch.hotbar = [
    "C01-A01",
    "C01-A02",
    "C01-A03",
    "C01-A07",
    "C01-A16",
    "C01-A32",
    "C01-U03",
    "C01-B01",
    "C01-B04",
  ];
  ch.skillPts = 200;
  ch.map = "training";
  ch.x = 30;
  ch.y = 20;
  account.chars = [ch.id];
  account.sel = ch.id;
  account.nick = ch.name;
  db.data.chars[ch.id] = ch;
  db.save();
  const port = 18081,
    server = spawn(process.execPath, ["server/index.js"], {
      cwd: path.resolve(__dirname, ".."),
      env: { ...process.env, PORT: String(port) },
      stdio: ["ignore", "pipe", "pipe"],
    });
  const logs = [];
  server.stderr.on("data", (b) => logs.push(String(b)));
  let browser;
  try {
    await new Promise((r, j) => {
      server.stdout.once("data", r);
      server.once("error", j);
      setTimeout(() => j(Error("startup timeout")), 10000).unref();
    });
    const { chromium } = require("playwright");
    browser = await chromium.launch({
      executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
      headless: true,
      args: ["--no-sandbox"],
    });
    const page = await browser.newPage({
        viewport: { width: 1440, height: 1000 },
      }),
      errors = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.goto("http://127.0.0.1:" + port);
    await page.fill("#user", "browserqa");
    await page.fill("#pass", "local-browser-test");
    await page.click("#loginBtn");
    await page.locator("[data-play]:visible").first().click();
    await page.waitForFunction(
      () => window.G && G.char && G.char.cls === "blademaster" && G.me,
    );
    await page.evaluate(() => {
      for (const w of [...UI.open]) UI.close(w);
    });
    fs.mkdirSync(path.join(__dirname, "../docs/skill-atlas/evidence"), {
      recursive: true,
    });
    await page.screenshot({
      path: path.join(__dirname, "../docs/skill-atlas/evidence/game.png"),
    });
    await page.evaluate(() => UI.show("skills"));
    await page.locator('[data-act="cat"][data-k="passive"]').click();
    assert.equal(await page.locator(".skCard").count(), 5);
    assert(
      (await page.locator(".skCard").allTextContents()).some((t) =>
        t.includes("C01-P01"),
      ),
    );
    await page.screenshot({
      path: path.join(__dirname, "../docs/skill-atlas/evidence/passives.png"),
    });
    await page.evaluate(() => {
      UI.close("skills");
      const enemy = [...G.ents.values()]
        .filter((e) => e.k === "m")
        .sort(
          (a, b) =>
            Math.hypot(a.x - G.self.x, a.y - G.self.y) -
            Math.hypot(b.x - G.self.x, b.y - G.self.y),
        )[0];
      G.target = enemy.id;
    });
    // Exercise actual authoritative movement/cast request and capture the resulting server telegraph in the renderer.
    await page.evaluate(() => {
      G.mouse.wx = G.self.x + 4;
      G.mouse.wy = G.self.y;
      G.useSkill("C01-A02");
    });
    await page.waitForFunction(
      () =>
        window.ATLAS_VFX && ATLAS_VFX.effects.some((e) => e.sk === "C01-A02"),
    );
    await page.screenshot({
      path: path.join(__dirname, "../docs/skill-atlas/evidence/telegraph.png"),
    });
    await page.waitForTimeout(600);
    await page.evaluate(() => {
      const target = [...G.ents.values()].find(
        (e) =>
          e.k === "m" && Math.abs(e.x - 32) < 0.1 && Math.abs(e.y - 20) < 0.1,
      );
      G.target = target.id;
      G.useSkill("C01-A32");
    });
    await page.waitForTimeout(450);
    await page.evaluate(() => G.useSkill("C01-A03"));
    await page.waitForTimeout(450);
    await page.evaluate(() => G.useSkill("C01-A01"));
    await page.waitForFunction(() => G.sme.res >= 3);
    await page.waitForTimeout(300);
    await page.evaluate(() => G.useSkill("C01-A16"));
    await page.waitForFunction(() => G.sme.res === 0);
    await page.screenshot({
      path: path.join(__dirname, "../docs/skill-atlas/evidence/combo.png"),
    });

    assert.equal(await page.evaluate(() => G.st.maxSp), 100);
    assert.equal(errors.length, 0, errors.join("\n"));
    assert.equal(logs.length, 0, logs.join("\n"));
    console.log(
      "Browser PASS: login, saved character, Canvas gameplay, five passive cards, confirmed cast VFX, movement/resource combo/consumption, MP HUD, zero JS/server errors.",
    );
  } finally {
    await browser?.close();
    server.kill("SIGTERM");
    await new Promise((r) => server.once("exit", r));
    fs.rmSync(dir, { recursive: true, force: true });
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
