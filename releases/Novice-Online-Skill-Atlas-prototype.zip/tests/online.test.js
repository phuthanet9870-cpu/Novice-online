"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("fs"),
  os = require("os"),
  path = require("path"),
  { spawn } = require("child_process"),
  WS = require("ws");
test("real WebSocket peers share authoritative combat and migrate/save/reconnect without losing progression", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "novice-online-"));
  process.env.NO_DATA_DIR = dir;
  const db = require("../server/db").load(),
    I = require("../server/items");
  const owner = db.createAccount("ownerqa", "integration-test"),
    guest = db.createAccount("guestqa", "integration-test");
  for (const [acc, name] of [
    [owner, "OwnerQA"],
    [guest, "GuestQA"],
  ]) {
    const ch = I.newChar(acc, name, "blademaster");
    ch.lv = 100;
    ch.exp = 12345;
    ch.x = 30;
    ch.y = 20;
    ch.map = "training";
    ch.skills = { "C01-A01": 1, "C01-A03": 1 };
    ch.hotbar = ["C01-A01", "C01-A03"];
    acc.chars = [ch.id];
    acc.sel = ch.id;
    acc.nick = name;
    db.data.chars[ch.id] = ch;
  }
  const old = db.data.chars[owner.chars[0]];
  delete old.skillAtlasVersion;
  old.skillPts = 17;
  old.skills = { blademaster_a02: 5, blademaster_a01: 2, "C01-A03": 1 };
  old.hotbar = ["blademaster_a02", "blademaster_a01", "C01-A03"];
  const weapon = old.equip.weapon.uid;
  db.save();
  const original = fs.readFileSync(path.join(dir, "db.json"));
  let server,
    sockets = [];
  const logs = [];
  const port = 19877;
  async function boot() {
    server = spawn(process.execPath, ["server/index.js"], {
      cwd: path.resolve(__dirname, ".."),
      env: { ...process.env, PORT: String(port) },
      stdio: ["ignore", "pipe", "pipe"],
    });
    server.stderr.on("data", (b) => logs.push(String(b)));
    await new Promise((r, j) => {
      server.stdout.once("data", r);
      server.once("error", j);
      setTimeout(() => j(Error("startup timeout")), 10000).unref();
    });
  }
  async function stop() {
    for (const ws of sockets) ws.close();
    sockets = [];
    server.kill("SIGTERM");
    await new Promise((r) => server.once("exit", r));
  }
  async function client(user) {
    const ws = new WS("ws://127.0.0.1:" + port + "/ws"),
      inbox = [],
      waiters = [];
    sockets.push(ws);
    ws.on("message", (raw) => {
      const m = JSON.parse(raw);
      inbox.push(m);
      if (inbox.length > 2000) inbox.shift();
      for (const w of [...waiters])
        if (w.predicate(m)) {
          waiters.splice(waiters.indexOf(w), 1);
          clearTimeout(w.timer);
          w.resolve(m);
        }
    });
    function wait(predicate) {
      const existing = inbox.find(predicate);
      if (existing) return Promise.resolve(existing);
      return new Promise((resolve, reject) => {
        const w = {
          predicate,
          resolve,
          timer: setTimeout(
            () => reject(Error("message timeout " + user)),
            8000,
          ),
        };
        waiters.push(w);
      });
    }
    const send = (m) => ws.send(JSON.stringify(m));
    await wait((m) => m.t === "hello");
    send({ t: "login", user, pass: "integration-test" });
    const auth = await wait((m) => m.t === "auth");
    assert(auth.ok);
    send({ t: "play", id: auth.chars[0].id });
    const enter = await wait((m) => m.t === "enter");
    return { ws, wait, send, enter, inbox };
  }
  try {
    await boot();
    const a = await client("ownerqa"),
      b = await client("guestqa");
    assert.equal(a.enter.char.skillAtlasVersion, 1);
    assert.equal(a.enter.char.skills["C01-A01"], 1);
    assert.equal(a.enter.char.skillPts, 23);
    assert.equal(a.enter.char.exp, 12345);
    assert.equal(a.enter.char.equip.weapon.uid, weapon);
    assert.deepEqual(
      fs.readFileSync(path.join(dir, "db.json.pre-atlas-v1.bak")),
      original,
    );
    const spawn = await a.wait(
      (m) =>
        m.t === "snap" &&
        m.a?.some((e) => e.k === "m" && e.x === 320 && e.y === 200),
    );
    const target = spawn.a.find(
      (e) => e.k === "m" && e.x === 320 && e.y === 200,
    );
    assert(target);
    a.send({ t: "sk", id: "C01-A01", tid: target.id });
    await a.wait((m) => m.t === "snap" && m.me?.res === 1);
    await b.wait(
      (m) =>
        m.t === "snap" &&
        m.fx?.some(
          (e) => e.k === "hit" && e.s === a.enter.me && e.sk === "C01-A01",
        ),
    );
    for (let i = 0; i < 10; i++)
      a.send({ t: "sk", id: "C01-A01", tid: target.id, cost: 0, damage: 1e9 });
    assert((await a.wait((m) => m.t === "err")).m);
    b.send({ t: "sk", id: "blademaster_a02", tid: target.id });
    await b.wait((m) => m.t === "err");
    await new Promise((r) => setTimeout(r, 300));
    a.send({ t: "sk", id: "C01-A03", tid: target.id, x: 32, y: 20 });
    await a.wait(
      (m) =>
        m.t === "snap" &&
        m.atlas?.some(
          ([id, status]) =>
            id === target.id && status.some((s) => s.owner === a.enter.me),
        ),
    );
    b.send({ t: "sk", id: "C01-A03", tid: target.id, x: 32, y: 20 });
    await a.wait(
      (m) =>
        m.t === "snap" &&
        m.atlas?.some(([id, status]) => id === target.id && status.length >= 2),
    );
    await stop();
    const saved = JSON.parse(fs.readFileSync(path.join(dir, "db.json"))),
      ch = saved.chars[old.id];
    assert.equal(ch.exp, 12345);
    assert.equal(ch.skillPts, 23);
    assert.equal(ch.equip.weapon.uid, weapon);
    assert(!Object.keys(ch.skills).some((id) => id.startsWith("blademaster_")));
    await boot();
    const re = await client("ownerqa");
    assert.equal(re.enter.char.skillPts, 23);
    assert.equal(re.enter.char.skillAtlasVersion, 1);
    assert.equal(logs.length, 0, logs.join("\n"));
    await stop();
  } finally {
    for (const ws of sockets) ws.close();
    if (server && server.exitCode === null) {
      server.kill("SIGTERM");
      await new Promise((r) => server.once("exit", r));
    }
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
