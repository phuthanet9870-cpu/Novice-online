"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict");
const { arena, C, A, S } = require("./atlas-harness");
test("catalogue: every source ID, category, cost and VFX provenance is present", () => {
  const src = require("../docs/skill-atlas/source.json");
  assert.equal(src.skills.length, 1650);
  assert.equal(Object.keys(S.SKILLS).length, 1650);
  for (const x of src.skills) {
    const sk = S.SKILLS[x.id];
    assert(sk, x.id);
    assert.equal(sk.name, x.name);
    assert.equal(sk.page, x.page);
    assert(sk.vfx.description);
    assert(sk.atlas.delivery.type);
    assert(sk.sp >= 0 && sk.cd >= 0);
    assert.equal(sk.maxLv, 1);
    assert(!sk.prog);
  }
  for (const c of src.classes) {
    for (const [k, n] of Object.entries({
      attack: 40,
      ult: 5,
      buff: 5,
      passive: 5,
    }))
      assert.equal(
        Object.values(S.SKILLS).filter((s) => s.cls === c.key && s.kind === k)
          .length,
        n,
      );
  }
});
test("all 1500 castable skills execute their delivery without exceptions", () => {
  for (const sk of Object.values(S.SKILLS).filter(
    (s) => s.kind !== "passive",
  )) {
    const h = arena(sk.cls);
    try {
      const { result } = h.cast(sk.id);
      assert.equal(result.ok, true, sk.id + ": " + result.m);
      h.step(1.6);
      if (sk.atlas.delivery.recast && h.p.atlasRecasts?.[sk.id]) {
        const r = C.useSkill(
          h.p,
          sk.id,
          h.enemy.id,
          52,
          50,
          sk.atlas.delivery.type === "mine" && sk.atlas.delivery.cap === 3
            ? "detonate"
            : "cast",
        );
        assert.equal(r.ok, true, sk.id + " recast");
      }
      h.step(9);
    } catch (e) {
      e.message = sk.id + " " + sk.name + ": " + e.message;
      throw e;
    }
  }
});
test("Twin Fang: two authoritative hits, exact base coefficient and one resource gain", () => {
  const h = arena();
  h.p.res = 0;
  const id = "C01-A01";
  h.p.char.hotbar = [id];
  const hp = h.enemy.hp,
    power = A.power(h.p);
  assert(C.useSkill(h.p, id, h.enemy.id, 52, 50).ok);
  h.step(0.7);
  assert.equal(h.p.res, 1);
  assert.equal(
    h.events.filter((e) => e.k === "hit" && e.t === h.enemy.id).length,
    2,
  );
  assert(Math.abs(hp - h.enemy.hp - power * 0.95 * 2) <= 2);
});
test("resource consumers reject before spending MP and never go negative", () => {
  const h = arena(),
    id = "C01-A16";
  h.p.char.hotbar = [id];
  h.p.res = 2;
  const mp = h.p.sp;
  assert.equal(C.useSkill(h.p, id, h.enemy.id).ok, false);
  assert.equal(h.p.sp, mp);
  h.p.res = 3;
  assert(C.useSkill(h.p, id, h.enemy.id).ok);
  assert.equal(h.p.res, 0);
  assert.equal(C.useSkill(h.p, id, h.enemy.id).ok, false);
});
test("owner-scoped status caps, refreshes, expires and consumption cannot steal another player stacks", () => {
  const h = arena();
  for (let i = 0; i < 8; i++) A.addStatus(h.p, h.enemy);
  A.addStatus(h.ally, h.enemy, 3);
  assert.equal(A.stacks(h.p, h.enemy), 5);
  assert.equal(A.takeStatus(h.p, h.enemy), 5);
  assert.equal(A.stacks(h.ally, h.enemy), 3);
  h.step(7);
  assert.equal(A.stacks(h.ally, h.enemy), 0);
});
test("telegraphs precede damage and range, walls, NaN and rate checks are server-side", () => {
  const h = arena(),
    id = "C01-A01";
  h.p.char.hotbar = [id];
  const hp = h.enemy.hp;
  assert.equal(C.useSkill(h.p, id, h.enemy.id, NaN, 0).ok, false);
  h.enemy.x = 90;
  assert.equal(C.useSkill(h.p, id, h.enemy.id).ok, false);
  h.enemy.x = 52;
  h.inst.map.walk[50 * 128 + 51] = 0;
  assert.equal(C.useSkill(h.p, id, h.enemy.id).ok, false);
  h.inst.map.walk[50 * 128 + 51] = 1;
  assert(C.useSkill(h.p, id, h.enemy.id).ok);
  assert.equal(h.enemy.hp, hp);
  assert(h.events.some((e) => e.k === "atlas" && e.phase === "prepare"));
  assert.equal(C.useSkill(h.p, id, h.enemy.id).ok, false);
  h.step(0.7);
  assert(h.enemy.hp < hp);
});
test("migration refunds unmatched ranks and preserves character, gear, item slots and idempotence", () => {
  const m = require("../shared/skill-migration");
  const ch = {
    cls: "blademaster",
    name: "Existing",
    lv: 100,
    exp: 123,
    skillPts: 7,
    skills: { blademaster_a02: 5, blademaster_a01: 3, blademaster_u1: 2 },
    hotbar: ["blademaster_a02", "blademaster_a01", "item:pot_hp_1"],
    equip: { weapon: { uid: "owned" } },
    inv: [{ uid: "loot" }],
    auto: { rotation: [{ id: "blademaster_a02" }, { id: "blademaster_a01" }] },
  };
  const copy = structuredClone(ch),
    r = m.migrate(copy);
  assert.equal(r.refund, 11);
  assert.equal(copy.skills["C01-A01"], 1);
  assert.equal(copy.skillPts, 18);
  assert.equal(copy.hotbar[0], "C01-A01");
  assert.equal(copy.hotbar[1], null);
  assert.equal(copy.hotbar[2], "item:pot_hp_1");
  assert.deepEqual(copy.equip, ch.equip);
  assert.deepEqual(copy.inv, ch.inv);
  assert.equal(copy.exp, 123);
  assert.equal(m.migrate(copy).changed, false);
  assert.equal(ch.skills.blademaster_a02, 5);
});
test("Cross Verdict consumes only own marks and applies resource amplification to damage", () => {
  const h = arena();
  const id = "C01-A16";
  h.p.char.hotbar = [id];
  h.p.res = 3;
  A.addStatus(h.p, h.enemy, 3);
  A.addStatus(h.ally, h.enemy, 5);
  const hp = h.enemy.hp,
    power = A.power(h.p);
  assert(C.useSkill(h.p, id, h.enemy.id).ok);
  h.step(0.2);
  assert.equal(A.stacks(h.p, h.enemy), 0);
  assert.equal(A.stacks(h.ally, h.enemy), 5);
  assert(Math.abs(hp - h.enemy.hp - (1.5 + 3 * 0.6) * 1.25 * power) < 2);
});
test("Iron Answer reduces frontal damage 80%, counters once, creates exactly two resource", () => {
  const h = arena();
  h.p.char.hotbar = ["C01-A07"];
  h.p.res = 0;
  h.enemy.atk = 100;
  h.enemy.lv = 1;
  h.p.st.def = 0;
  h.p.st.dmgReduce = 0;
  h.p.st.flee = 0;
  h.p.dir = 0;
  assert(C.useSkill(h.p, "C01-A07", h.enemy.id).ok);
  h.step(0.2);
  const before = h.p.hp;
  C.dealDamage(h.enemy, h.p, { flat: 100, kind: "mob" });
  assert.equal(before - h.p.hp, 20);
  assert.equal(h.p.res, 2);
  const hits = h.events.filter(
    (e) => e.k === "hit" && e.t === h.enemy.id,
  ).length;
  C.dealDamage(h.enemy, h.p, { flat: 100, kind: "mob" });
  assert.equal(h.p.res, 2);
  assert.equal(
    h.events.filter((e) => e.k === "hit" && e.t === h.enemy.id).length,
    hits,
  );
});
test("False Opening requires a second press and retains one payment and cooldown", () => {
  const h = arena(),
    id = "C01-A21";
  h.p.char.hotbar = [id];
  h.p.res = 0;
  assert(C.useSkill(h.p, id, h.enemy.id).ok);
  const mp = h.p.sp,
    cd = h.p.cds[id],
    hp = h.enemy.hp;
  h.step(0.6);
  assert.equal(h.enemy.hp, hp);
  assert(C.useSkill(h.p, id, h.enemy.id).ok);
  h.step(0.2);
  assert(h.enemy.hp < hp);
  assert.equal(h.p.sp, mp);
  assert.equal(h.p.cds[id], cd);
  assert.equal(h.p.res, 1);
});
test("movement cannot cross walls, blink cannot clear root and costs remain unchanged on rejected casts", () => {
  const h = arena(),
    id = "C01-A32";
  h.p.char.hotbar = [id];
  h.p.tags.set("root", { until: h.time() + 4 });
  const mp = h.p.sp;
  assert.equal(C.useSkill(h.p, id, 0, 55, 50).ok, false);
  assert.equal(h.p.sp, mp);
  h.p.tags.delete("root");
  h.inst.map.walk[50 * 128 + 52] = 0;
  assert.equal(C.useSkill(h.p, id, 0, 55, 50).ok, false);
  assert.equal(h.p.x, 50);
});
test("echo damage never generates marks or direct-hit resources", () => {
  const h = arena("chronomancer");
  h.cast("C19-A01");
  h.step(0.5);
  assert(h.p.atlasEcho);
  const saved = h.p.res;
  h.cast("C19-A06");
  const afterPayment = h.p.res;
  h.step(2);
  assert.equal(h.p.res, afterPayment);
  assert(h.enemy.hp < 1e8);
  assert(h.p.res <= saved);
});
test("PvP control duration and diminishing returns use a six-second window", () => {
  const h = arena();
  h.inst.pvp = true;
  assert(A.control(h.p, h.ally, { tag: "stun", duration: 0.8 }));
  assert(Math.abs(h.ally.tags.get("stun").until - h.time() - 0.4) < 0.001);
  assert(A.control(h.p, h.ally, { tag: "stun", duration: 0.8 }));
  assert(Math.abs(h.ally.tags.get("stun").until - h.time() - 0.2) < 0.001);
  assert.equal(A.control(h.p, h.ally, { tag: "stun", duration: 0.8 }), false);
  h.step(6.1);
  assert(A.control(h.p, h.ally, { tag: "stun", duration: 0.8 }));
});
test("full-resource execute checks HP at impact and does not replace a vanished target", () => {
  const h = arena(),
    id = "C01-A40";
  h.p.char.hotbar = [id];
  h.p.res = 5;
  h.enemy.hp = h.enemy.maxHp * 0.5;
  assert(C.useSkill(h.p, id, h.enemy.id).ok);
  h.enemy.hp = h.enemy.maxHp * 0.2;
  const hp = h.enemy.hp,
    power = A.power(h.p);
  h.step(0.2);
  assert(Math.abs(hp - h.enemy.hp - power * 3.6 * 1.5) <= 2);
  assert.equal(h.p.res, 0);
});
test("summon groups enforce separate ordinary and ultimate caps", () => {
  const h = arena("necromancer");
  for (let i = 0; i < 3; i++) {
    h.cast("C08-A04");
    h.step(0.2);
  }
  assert.equal(
    h.p.summons.filter((s) => !s.dead && s.atlasGroup === "follower").length,
    2,
  );
  const ordinary = h.p.summons.filter(
    (s) => !s.dead && s.atlasGroup === "follower",
  );
  const ult = Object.values(S.SKILLS).find(
    (s) => s.cls === "necromancer" && s.atlas.delivery.type === "army",
  );
  h.cast(ult.id);
  h.step(0.2);
  assert.equal(
    h.p.summons.filter((s) => !s.dead && s.atlasGroup === "army").length,
    5,
  );
  assert(ordinary.every((s) => !s.dead));
});
test("passive equip rejects unlearned, duplicates, excess slots and combat changes", () => {
  const { I } = require("./atlas-harness");
  const h = arena();
  const before = h.p.char.skillPassives;
  I.setSkillPassives(h.p, ["C01-P01", "C01-P01"]);
  assert.deepEqual(h.p.char.skillPassives, before);
  I.setSkillPassives(h.p, ["C01-P01", "C01-P02", "C01-P03", "C01-P04"]);
  assert.deepEqual(h.p.char.skillPassives, before);
  I.setSkillPassives(h.p, ["C01-P01"]);
  assert.deepEqual(h.p.char.skillPassives, ["C01-P01"]);
  h.p.lastHit = h.time();
  I.setSkillPassives(h.p, []);
  assert.deepEqual(h.p.char.skillPassives, ["C01-P01"]);
});
test("every castable skill rejects unlearned and cross-class requests; pays the documented MP/resource exactly once", () => {
  for (const sk of Object.values(S.SKILLS).filter(
    (s) => s.kind !== "passive",
  )) {
    const h = arena(sk.cls),
      { result } = h.cast(sk.id);
    assert.equal(result.ok, true, sk.id);
    assert.equal(h.p.sp, 100 - sk.sp, sk.id + " MP");
    const cap = S.ATLAS_CLASSES[sk.cls].resource.max;
    assert.equal(h.p.res, cap - sk.needRes, sk.id + " resource");
    const mp = h.p.sp;
    assert.equal(
      C.useSkill(h.p, sk.id, h.enemy.id, 52, 50).ok,
      false,
      sk.id + " repeated request",
    );
    assert.equal(h.p.sp, mp);
    h.p.casting = null;
    h.p.cds = {};
    h.p.atlasGcd = 0;
    delete h.p.atlasRecasts?.[sk.id];
    delete h.p.char.skills[sk.id];
    assert.equal(
      C.useSkill(h.p, sk.id, h.enemy.id).ok,
      false,
      sk.id + " unlearned",
    );
    const foreign = Object.values(S.SKILLS).find((q) => q.cls !== sk.cls);
    assert.equal(
      C.useSkill(h.p, foreign.id, h.enemy.id).ok,
      false,
      sk.id + " foreign",
    );
  }
});
test("damage, healing, shield coefficients and cooldowns match the PDF source values independently", () => {
  const src = require("../docs/skill-atlas/source.json");
  let damage = 0;
  for (const x of src.skills) {
    const sk = S.SKILLS[x.id],
      d = sk.atlas.delivery;
    assert.equal(
      sk.cd,
      Number(x.cost.match(/CD (\d+(?:\.\d+)?)/)?.[1] || 0),
      x.id,
    );
    assert.equal(sk.sp, Number(x.cost.match(/(\d+) MP/)?.[1] || 0), x.id);
    if (d.damage) {
      const range = x.description.match(/(\d+)-(\d+)% D/),
        first = x.description.match(/(\d+)% D/);
      if (first) {
        const expected = Number(range?.[1] || first[1]) / 100;
        assert.equal(d.damage, expected, x.id + " damage");
        damage++;
      }
    }
    if (
      d.heal &&
      ["heal", "partyHeal", "healingZone", "sanctuary", "seed"].includes(d.type)
    ) {
      const expected = x.description.match(/(\d+)% S/);
      assert(expected, x.id);
      assert.equal(d.heal, Number(expected[1]) / 100, x.id + " healing");
    }
  }
  assert(damage > 1000);
});
test("all 150 passive records can be equipped individually and dispatched on relevant combat events", () => {
  for (const sk of Object.values(S.SKILLS).filter(
    (s) => s.kind === "passive",
  )) {
    const h = arena(sk.cls);
    h.p.char.skillPassives = [sk.id];
    assert(A.has(h.p, Number(sk.id.slice(-2))), sk.id);
    const attack = Object.values(S.SKILLS).find(
        (s) => s.cls === sk.cls && s.atlas.delivery.damage,
      ),
      ctx = A.testContext(h.p, attack, h.enemy, 52, 50);
    for (const event of [
      "cast",
      "resolved",
      "hit",
      "hurt",
      "heal",
      "shield",
      "status",
      "second",
      "move",
      "movementSkill",
      "parry",
      "displace",
      "rewind",
      "portalReturn",
      "dispel",
      "cleanse",
      "rescue",
      "revive",
      "swap",
      "unitHit",
      "unitExpire",
      "unitDestroyed",
      "fieldExpire",
      "trapTrigger",
      "shieldDamage",
      "statusCleansed",
      "stealthBroken",
      "command",
      "delayed",
      "nearDeath",
      "kill",
    ]) {
      const unit = {
          ...h.enemy,
          owner: h.p,
          atlasGroup: "follower",
          atlasCreated: h.time() - 4,
          atlasCtx: ctx,
        },
        field = { kind: "zone", at: h.time() - 4, ctx };
      A.event(h.p, event, {
        ctx,
        source: h.enemy,
        target: h.enemy,
        unit,
        field,
        got: 10,
        before: 1,
        overheal: 10,
        stacks: 5,
        previous: 4,
        distance: 6,
        skill: false,
        key: attack.id,
      });
    }
    assert(h.p.sp >= 0 && h.p.sp <= h.p.maxSp, sk.id);
    assert(
      h.p.res >= 0 && h.p.res <= S.ATLAS_CLASSES[sk.cls].resource.max,
      sk.id,
    );
  }
});
test("approved spread rule copies to at most four enemies without incrementing an existing stack", () => {
  const h = arena();
  A.addStatus(h.p, h.enemy, 3);
  const near = [...h.inst.entities.values()].filter(
    (o) => o.kind === "m" && o !== h.enemy,
  );
  A.addStatus(h.p, near[0], 1);
  h.cast("C01-A29");
  h.step(0.2);
  assert.equal(A.stacks(h.p, h.enemy), 3);
  assert.equal(A.stacks(h.p, near[0]), 1);
  assert(near.slice(1).every((o) => A.stacks(h.p, o) === 3));
});
test("cleanse removes real class-owned states, triggers the owner exception and grants no resource on clean targets", () => {
  const h = arena("cleric");
  const enemySource = {
    ...h.p,
    cls: "cryomancer",
    char: { ...h.p.char, skillPassives: ["C06-P05"] },
    atlasProc: {},
  };
  A.addStatus(enemySource, h.ally, 5);
  const sk = S.SKILLS["C09-A05"],
    ctx = A.testContext(h.p, sk, h.ally, 51, 51);
  assert.equal(A.cleanse(h.p, h.ally, 2, ctx), 1);
  assert.equal(A.stacks(enemySource, h.ally), 0);
  assert(h.ally.atlasWinter.has(enemySource.id));
  A.addStatus(enemySource, h.ally, 1);
  assert.equal(A.stacks(enemySource, h.ally), 2);
  A.takeStatus(enemySource, h.ally);
  assert.equal(A.cleanse(h.p, h.ally, 2, ctx), 0);
});
test("named shield refresh takes the stronger remaining value and does not accumulate the same skill", () => {
  const h = arena();
  A.shield(h.p, h.p, 100, 4, "same");
  A.shield(h.ally, h.p, 40, 2, "same");
  assert.equal(h.p.shield, 100);
  assert.equal(h.p.atlasShields.get("same").amount, 100);
  assert.equal(h.p.atlasShields.get("same").src, h.p);
  h.step(2.5);
  A.expire(h.p, h.time());
  assert.equal(h.p.shield, 100);
  h.step(2);
  A.expire(h.p, h.time());
  assert.equal(h.p.shield, 0);
});
test("approved mine controls place three independent mines and secondary action detonates them together", () => {
  const h = arena("pyromancer"),
    id = "C05-A22";
  for (let i = 0; i < 3; i++) {
    h.p.char.hotbar = [id];
    h.p.cds = {};
    h.p.atlasGcd = 0;
    h.p.sp = 100;
    h.p.res = 100;
    assert(C.useSkill(h.p, id, h.enemy.id, 52 + i * 0.3, 50, "cast").ok);
    h.step(0.3);
  }
  const live = h.p.atlasFields.filter(
    (z) => z.kind === "mine" && z.until > h.time(),
  );
  assert.equal(live.length, 3);
  const mp = h.p.sp;
  assert(C.useSkill(h.p, id, h.enemy.id, 52, 50, "detonate").ok);
  assert.equal(h.p.sp, mp);
  assert.equal(
    h.p.atlasFields.filter((z) => z.kind === "mine" && z.until > h.time())
      .length,
    0,
  );
});
test("Unbroken Tempo applies its resource exception on interruption without refunding MP", () => {
  const h = arena();
  h.p.char.skillPassives = ["C01-P03"];
  h.p.char.hotbar = ["C01-A40"];
  h.p.res = 5;
  assert(C.useSkill(h.p, "C01-A40", h.enemy.id).ok);
  const mp = h.p.sp;
  assert.equal(h.p.res, 0);
  A.interrupt(h.p);
  assert.equal(h.p.res, 4);
  assert.equal(h.p.sp, mp);
});
test("Guardian owned armor-crack states mitigate normal PvE attackers, not only players", () => {
  const h = arena("guardian");
  h.p.st.dmgReduce = 0;
  h.p.st.flee = 0;
  h.p.pfx = {};
  A.addStatus(h.p, h.enemy, 3);
  const before = h.p.hp;
  C.dealDamage(h.enemy, h.p, { flat: 100, kind: "mob" });
  assert.equal(before - h.p.hp, 94);
});
