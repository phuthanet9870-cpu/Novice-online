"use strict";
const fs = require("fs"),
  path = require("path"),
  assert = require("assert/strict");
const root = path.resolve(__dirname, "../.."),
  src = require("../../docs/skill-atlas/source.json"),
  balance = require("../../docs/skill-atlas/balance.json");
const config = require("../../docs/skill-atlas/rules.json");
assert(
  config.loadout.attack + config.loadout.ult + config.loadout.buff <=
    config.itemStart,
);
assert(config.loadout.passive <= 5);
const SKILLS = {},
  CLASS_SKILLS = {},
  PASSIVES = {},
  KITINFO = {},
  ATLAS_CLASSES = {};
for (const c of src.classes) {
  CLASS_SKILLS[c.key] = [];
  PASSIVES[c.key] = [];
  ATLAS_CLASSES[c.key] = c;
  KITINFO[c.key] = {
    concept: c.concept,
    resource: c.resource,
    status: c.status,
  };
}
const sourceById = Object.fromEntries(src.skills.map((s) => [s.id, s]));
for (const b of balance) {
  assert(!SKILLS[b.id], "duplicate " + b.id);
  const x = sourceById[b.id];
  assert(x && x.classKey === b.cls);
  const d = b.delivery,
    c = ATLAS_CLASSES[b.cls];
  const kind = { A: "attack", U: "ult", B: "buff", P: "passive" }[b.category];
  assert(kind);
  assert(Number.isFinite(b.mana) && b.mana >= 0);
  assert(Number.isFinite(b.cooldown) && b.cooldown >= 0);
  assert(b.effects.resource.cost <= c.resource.max);
  assert(d.type);
  const shape = ["cone", "coneChannel"].includes(d.type)
    ? "cone"
    : [
          "line",
          "pierce",
          "beam",
          "snipe",
          "chargedLine",
          "dash",
          "boomerang",
          "fan",
        ].includes(d.type)
      ? "line"
      : d.radius
        ? "circle"
        : d.range === 0
          ? "self"
          : "single";
  const sk = {
    id: b.id,
    cls: b.cls,
    name: x.name,
    kind,
    idx: Number(b.id.slice(5)),
    maxLv: 1,
    reqLv: 1,
    lv: 1,
    sp: b.mana,
    cd: b.cooldown,
    cast: d.cast === undefined ? config.defaultWindup : d.cast,
    range: d.range,
    radius: d.radius || 0,
    length: d.length || 0,
    width: d.width || 1,
    shape,
    self: d.range === 0,
    dmg: d.damage || 0,
    hits: d.hits || 1,
    element: require("../class-roster")[b.cls].element,
    needRes: b.effects.resource.cost,
    consumeRes: b.effects.resource.full,
    role: b.effects.resource.cost ? "F" : b.effects.applyStatus ? "L" : "S",
    desc: x.description,
    note: x.vfx,
    page: x.page,
    mods: d.mods || {},
    dur: d.duration || 0,
    atlas: b,
    fx: {
      c: [c.color, "#fff", "#252337"],
      p: "nova",
      n: 8,
      m: "cw",
      pn: d.type,
      mn: "รูปทรงต้นแบบ / placeholder",
    },
    animation: {
      prepare: d.type,
      travel: d.speed ? "projectile" : null,
      impact: d.type,
      dissolve: kind === "ult" ? 0.5 : kind === "buff" ? 0.25 : 0.3,
    },
    vfx: {
      status: "placeholder",
      description: x.vfx,
      phases: ["prepare", "travel", "impact", "dissolve"],
    },
  };
  SKILLS[b.id] = sk;
  if (kind === "passive") PASSIVES[b.cls].push(sk);
  else CLASS_SKILLS[b.cls].push(b.id);
}
assert.equal(Object.keys(SKILLS).length, 1650);
for (const c of src.classes)
  for (const [k, n] of Object.entries({
    attack: 40,
    ult: 5,
    buff: 5,
    passive: 5,
  }))
    assert.equal(
      Object.values(SKILLS).filter((s) => s.cls === c.key && s.kind === k)
        .length,
      n,
    );
const data = {
  SKILLS,
  CLASS_SKILLS,
  PASSIVES,
  KITINFO,
  ATLAS_CLASSES,
  CONFIG: config,
};
fs.writeFileSync(
  path.join(root, "shared/skills.js"),
  "// Generated from docs/skill-atlas/balance.json; node tools/build-skills5.js\n(function(root,data){if(typeof module==='object'&&module.exports)module.exports=data;else root.NO_SKILLS=data;})(typeof self!=='undefined'?self:this," +
    JSON.stringify(data) +
    ");\n",
);
console.log(
  "Atlas validated: 30 classes / 1650 skills (1200 Active, 150 Ultimate, 150 Buff, 150 Passive)",
);
