"use strict";
const fs = require("fs"),
  path = require("path"),
  { templates, army } = require("./templates");
const root = path.resolve(__dirname, "../.."),
  source = require("../../docs/skill-atlas/source.json");
const clean = (s) => s.replace(/\s+/g, "").replace(/;/g, "");
const records = [];
const missing = [];
for (const x of source.skills) {
  const c = source.classes.find((c) => c.key === x.classKey),
    d = x.description,
    compact = clean(d),
    category = x.id[4];
  let t =
    category === "P"
      ? { type: "passive", range: 0 }
      : templates.find((t) => compact.startsWith(clean(t.prefix)));
  if (
    !t &&
    category === "U" &&
    compact.startsWith("อัญเชิญ") &&
    compact.includes("ห้ำตน8วินำที")
  )
    t = army;
  if (!t) {
    missing.push([x.id, d]);
    continue;
  }
  t = JSON.parse(JSON.stringify(t));
  delete t.prefix;
  const cd = Number((x.cost.match(/CD (\d+(?:\.\d+)?)/) || [])[1] || 0),
    mp = Number((x.cost.match(/(\d+) MP/) || [])[1] || 0),
    cost = Number((x.cost.match(/MP\s*\+\s*(\d+)/) || [])[1] || 0);
  const gainMatch = compact.match(/ได้[^\d]+(\d+)หน่วย/),
    gain = gainMatch ? Number(gainMatch[1]) : 0;
  let trigger = "none";
  if (gain) {
    if (compact.includes("เคลื่อนที่สำเร็จอย่ำงน้อย3")) trigger = "move3";
    else if (compact.includes("เคลื่อนที่จริงรวม6")) trigger = "walk6";
    else if (compact.includes("ไม่เสียHP")) trigger = "unhurt";
    else if (compact.includes("สังหำรศัตรูที่มี")) trigger = "killMarked";
    else if (compact.includes("ล้ำงสถำนะลบได้")) trigger = "cleanse";
    else if (
      compact.includes("กดใช้สำเร็จ") ||
      compact.includes("วำงเมล็ดสำเร็จ") ||
      compact.includes("สร้ำงยูนิตสำเร็จ")
    )
      trigger = "success";
    else if (compact.includes("ทำเงื่อนไขหลักสำเร็จ")) trigger = "condition";
    else trigger = "hit";
  }
  const effects = {
    resource: { cost, full: x.cost.includes("เต็ม"), gain, trigger },
    applyStatus: compact.includes("หำกโดนศัตรูเพิ่มสถำนะ")
      ? compact.includes("สองชั้น")
        ? 2
        : 1
      : 0,
    markedStagger: compact.includes("ทรงตัว30%") ? 0.3 : 0,
    lowAllyBonus: compact.includes("HPต่ำกว่ำ40%เพิ่มผล") ? 0.2 : 0,
  };
  if (category === "B") {
    effects.firstHitStatus =
      compact.includes("ครั้งแรก") &&
      compact.includes("เพิ่ม") &&
      compact.includes("หนึ่งชั้น");
    effects.firstMarkedMana = compact.includes("คืนมำนำ5หน่วย") ? 5 : 0;
    effects.lowAllyDuration = compact.includes("เพิ่มระยะเวลำบัฟของผู้นั้น1")
      ? 1
      : 0;
    effects.spendBuffBoost = cost ? 0.2 : 0;
  }
  records.push({
    id: x.id,
    cls: c.key,
    category,
    delivery: t,
    effects,
    cooldown: cd,
    mana: mp,
    scaling: c.basis,
    exception: d.includes("เฉพาะสกิล:")
      ? d.split("เฉพาะสกิล:")[1].trim()
      : null,
  });
}
if (missing.length) {
  console.error(JSON.stringify(missing, null, 2));
  process.exit(1);
}
fs.writeFileSync(
  path.join(root, "docs/skill-atlas/balance.json"),
  JSON.stringify(records, null, 2) + "\n",
);
console.log(
  "Imported",
  records.length,
  "skills; delivery types",
  new Set(records.map((s) => s.delivery.type)).size,
);
