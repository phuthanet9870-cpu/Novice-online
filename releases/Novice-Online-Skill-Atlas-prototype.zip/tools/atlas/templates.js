"use strict";
// Explicit delivery templates transcribed from the PDF. Numbers are prototype balance, not name-based effects.
const templates = [];
function add(prefix, type, values) {
  templates.push({ prefix, type, ...values });
}
add("โจมตีสองครั้ง", "multi", {
  range: 2,
  damage: 0.95,
  hits: 2,
  interval: 0.18,
});
add("พุ่งไปทิศ", "dash", { range: 6, length: 6, width: 1, damage: 1.5 });
add("กวำดกรวย", "cone", { range: 4, radius: 4, angle: 100, damage: 1.8 });
add("ตีตรำเป้ำ", "mark", { range: 12, duration: 6, charges: 3, damage: 0.45 });
add("เตรียมท่ำ 0.7", "heavy", { range: 3, damage: 3, cast: 0.7 });
add("หมุนโจมตี", "spin", {
  range: 0,
  radius: 3,
  damage: 0.6,
  hits: 4,
  interval: 0.25,
});
add("ตั้งรับ 0.6", "parry", {
  range: 3,
  duration: 0.6,
  reduction: 0.8,
  damage: 2.2,
});
add("ใช้ภำยใน 2", "riposte", {
  range: 3,
  damage: 2.6,
  condition: "recentDefense",
  window: 2,
});
add("กระโดดไป", "leap", { range: 5, radius: 2, damage: 1.7 });
add("ถอยหลัง", "retreat", { range: 4, length: 4, damage: 1.3, angle: 100 });
add("แทงเป็นเส้น", "line", {
  range: 6,
  length: 6,
  width: 1,
  damage: 2.1,
  secondary: 0.5,
});
add("โจมตีสำมครั้ง", "multi", {
  range: 3,
  damage: 0.7,
  hits: 3,
  interval: 0.18,
  staggerLast: 1.3,
});
add("โจมตีระยะ 4 ม. 180", "shieldbreak", {
  range: 4,
  damage: 1.8,
  shieldBonus: 1,
});
add("โจมตีวงรัศมี", "circle", {
  range: 10,
  radius: 4,
  damage: 1.3,
  control: { tag: "slow", duration: 3, pct: 30 },
});
add("โจมตีเป้ำหมำยระยะ 4 ม. 130", "single", {
  range: 4,
  damage: 1.3,
  control: { tag: "stun", duration: 0.8 },
});
add("ลบสถำนะเฉพำะ", "consume", { range: null, damage: 1.5, perStack: 0.6 });
add("ขว้ำงอำวุธ", "boomerang", {
  range: 9,
  length: 9,
  width: 1,
  damage: 1.1,
  speed: 18,
  maxTravel: 20,
});
add("ยิงทะลุเป็นเส้น", "pierce", {
  range: 14,
  length: 14,
  width: 1,
  damage: 1.9,
  maxTargets: 5,
  speed: 18,
});
add("ผูกศัตรู", "tether", { range: 8, duration: 3, breakRange: 4, damage: 2 });
add("พุ่งหำเป้ำ", "charge", { range: 8, length: 8, damage: 1.9 });
add("ทำท่ำหลอก", "feint", {
  range: null,
  damage: 2,
  cast: 0.5,
  recast: true,
  duration: 2,
});
add("ตั้งกระบวนท่ำ", "stance", { range: 0, damage: 1.5, duration: 3 });
add("ตั้งโล่รับ", "guard", {
  range: 0,
  duration: 1.5,
  reduction: 0.6,
  movePct: -50,
});
add("ยิงเป้ำหมำยระยะ 10 ม. 100% D; ขัด", "single", {
  range: 10,
  damage: 1,
  control: { tag: "silence", duration: 1 },
  speed: 18,
});
add("กวำดรอบตัว", "spin", { range: 0, radius: 3, damage: 1.7, hits: 1 });
add("กำหนดเส้นยำว", "tripleImpact", {
  range: 10,
  length: 10,
  radius: 1.5,
  damage: 1.3,
  cast: 0.7,
  maxHitsPerTarget: 2,
});
add("วำงพื้นที่รัศมี", "circle", {
  range: 9,
  radius: 3,
  damage: 1,
  control: { tag: "root", duration: 1.2 },
});
add("ระเบิดสถำนะเฉพำะ", "consumeArea", {
  range: 0,
  radius: 5,
  damage: 1.2,
  perStack: 0.4,
});
add("คัดลอกสถำนะเฉพำะ", "spread", { range: null, radius: 4, maxTargets: 4 });
add("โจมตีกรวย 4 ม. 140", "cone", {
  range: 4,
  radius: 4,
  angle: 100,
  damage: 1.4,
  push: 2,
});
add("โจมตีระยะ 4 ม. 120", "single", {
  range: 4,
  damage: 1.2,
  control: { tag: "disarm", duration: 1 },
});
add("ย้ำยไปจุด", "blink", { range: 5, length: 5 });
add("สร้ำงเขตรัศมี 4 ม. ระยะ", "zone", {
  range: 10,
  radius: 4,
  duration: 5,
  interval: 1,
  damage: 0.5,
});
add("สร้ำงกำแพง", "wall", { range: 0, length: 5, width: 0.3, duration: 3 });
add("โจมตีระยะ 2 ม. 170", "backstab", {
  range: 2,
  damage: 1.7,
  backDamage: 2.9,
});
add("โจมตีเป้ำหมำยระยะ 8 ม. 160", "killReset", {
  range: 8,
  damage: 1.6,
  resetPct: 0.5,
});
add("โจมตีระยะ 3 ม. 120", "single", {
  range: 3,
  damage: 1.2,
  dot: { damage: 0.4, duration: 4, interval: 1, tag: "bleed" },
});
add("ชำร์จได้", "chargedLine", {
  range: 8,
  length: 8,
  width: 1,
  damage: 1.5,
  maxDamage: 3.3,
  cast: 1,
  recast: true,
});
add("ตีวงรัศมี", "spin", {
  range: 0,
  radius: 3,
  damage: 1.6,
  hits: 1,
  pull: 1,
});
add("โจมตีเป้ำหมำยระยะ 5 ม. 240", "execute", {
  range: 5,
  damage: 2.4,
  threshold: 0.25,
  executeDamage: 3.6,
});
add("ล็อกเป้ำหมำย", "duel", {
  range: 6,
  cast: 0.7,
  hits: 5,
  interval: 0.2,
  damage: 1.6,
  breakRange: 10,
});
add("ยืนเตรียม", "coneChannel", {
  range: 14,
  radius: 14,
  angle: 100,
  cast: 0.8,
  hits: 8,
  interval: 0.15,
  damage: 1.2,
});
add("สร้ำงอำณำเขต", "domain", {
  range: 0,
  radius: 7,
  duration: 8,
  interval: 1,
  damage: 0.75,
  allyReduction: 15,
});
add("เข้ำสภำวะพิเศษ", "transform", {
  range: 0,
  duration: 8,
  mods: { dmgPct: 25, range: 2 },
});
add("เตรียม 1 วินำทีโจมตี", "execute", {
  range: 8,
  cast: 1,
  damage: 7,
  threshold: 0.2,
  executeDamage: 10,
});
add("ตนเอง: เพิ่มโอกำส", "buff", { range: 0, duration: 6, mods: { crit: 12 } });
add("ตนเอง: ลดควำมเสียหำย", "buff", {
  range: 0,
  duration: 5,
  mods: { dmgReduce: 20 },
});
add("ตนเอง: เพิ่มควำมเร็ว", "buff", {
  range: 0,
  duration: 6,
  mods: { movePct: 20, slowRes: 30 },
});
add("พันธมิตรไม่เกินห้ำคนในรัศมี 6 ม.: เพิ่ม", "partyBuff", {
  range: 0,
  radius: 6,
  duration: 6,
  maxTargets: 5,
  mods: { dmgPct: 10 },
});
add("ตนเอง: กำรโจมตีตรงสำม", "manaBuff", {
  range: 0,
  duration: 6,
  charges: 3,
  manaDiscount: 0.3,
});
add("โจมตีเป้ำหมำยระยะ 2 ม. 160", "single", { range: 2, damage: 1.6 });
add("ยั่วยุศัตรู", "taunt", {
  range: 0,
  radius: 5,
  duration: 2,
  pvpWeaken: 15,
});
add("พุ่งไปพันธมิตร", "interpose", { range: 8, duration: 3, redirect: 0.35 });
add("ดึงศัตรูในวง", "circle", { range: 8, radius: 3, damage: 1.2, pull: 3 });
add("ดึงพันธมิตร", "rescue", {
  range: 10,
  shield: 1.2,
  duration: 2,
  consent: true,
});
add("ให้โล่พันธมิตร", "shield", { range: 10, shield: 2, duration: 4 });
add("วำงเขตรัศมี", "healingZone", {
  range: 0,
  radius: 4,
  duration: 5,
  interval: 1,
  heal: 0.3,
});
add("ยิงตะขอ", "hook", { range: 9, length: 9, damage: 1.3 });
add("วำงวงรัศมี", "clearZone", {
  range: 0,
  radius: 4,
  duration: 3,
  damage: 1.5,
  maxRemove: 1,
});
add("สร้ำงจุดพลัง", "mine", {
  range: 10,
  radius: 4,
  duration: 6,
  damage: 2.4,
  recast: true,
  cap: 1,
});
add("เตือนวงรัศมี 6 ม. 1.5", "nova", {
  range: 0,
  radius: 6,
  cast: 1.5,
  damage: 8.5,
  edgeMult: 0.6,
});
add("ร่ำย 1.5 วินำที ฟื้น", "partyHeal", {
  range: 12,
  radius: 12,
  cast: 1.5,
  heal: 6,
  shield: 1.5,
  duration: 3,
  maxTargets: 5,
});
add("เตือนวงรัศมี 6 ม. 1 วินำที", "nova", {
  range: 0,
  radius: 6,
  cast: 1,
  damage: 5.5,
  control: { tag: "root", duration: 1.5 },
});
add("พันธมิตรไม่เกินห้ำคนในรัศมี 6 ม.: ลด", "partyBuff", {
  range: 0,
  radius: 6,
  duration: 6,
  maxTargets: 5,
  mods: { dmgReduce: 12 },
});
add("ตนเองและพันธมิตร", "pairShield", {
  range: 8,
  shieldHp: 0.12,
  duration: 5,
  maxTargets: 2,
});
add("ตนเอง: เพิ่มทรัพยำกร", "resourceBuff", {
  range: 0,
  duration: 6,
  gainBonus: 0.5,
});
add("จ่ำย HP", "bloodNova", {
  range: 0,
  radius: 4,
  damage: 3,
  hpCost: 0.08,
  hpMinimum: 0.15,
});
add("เชื่อมศัตรูระยะ", "drain", {
  range: 8,
  duration: 2,
  hits: 2,
  interval: 1,
  damage: 1,
  drain: 0.2,
});
add("โจมตีกรวย 4 ม. 90", "cone", {
  range: 4,
  radius: 4,
  angle: 100,
  damage: 0.9,
  control: { tag: "fear", duration: 0.7 },
});
add("วำงกับดัก", "trap", {
  range: 8,
  radius: 2,
  duration: 8,
  damage: 2.2,
  control: { tag: "slow", duration: 2, pct: 40 },
});
add("ตนเอง: เพิ่มควำมเสียหำย", "buff", {
  range: 0,
  duration: 6,
  mods: { dmgPct: 15 },
});
add("ตนเอง: ฟื้น HP", "regenBuff", {
  range: 0,
  duration: 5,
  interval: 1,
  healHp: 0.02,
});
add("ฟื้น HP ให้พันธมิตรหนึ่ง", "heal", { range: 12, heal: 1.8 });
add("ฟื้น HP ให้พันธมิตรไม่เกิน", "partyHeal", {
  range: 0,
  radius: 5,
  heal: 1.2,
  maxTargets: 5,
});
add("ล้ำงสถำนะลบ", "cleanse", { range: 12, maxRemove: 2 });
add("โจมตีเป้ำหมำยแรก", "chain", {
  range: 12,
  damage: 1.6,
  secondary: 0.9,
  maxTargets: 4,
  chainRange: 5,
  speed: 18,
});
add("ลบผลบวก", "dispel", { range: 10, damage: 1.2, maxRemove: 1 });
add("ร่ำย 2 วินำที", "revive", {
  range: 12,
  cast: 2,
  healHp: 0.25,
  pveOnly: true,
});
add("ยิงกระสุนหนึ่ง", "projectile", {
  range: 12,
  length: 12,
  width: 0.5,
  damage: 1.7,
  maxTargets: 1,
  speed: 18,
});
add("ยิงกระสุนแยก", "fan", {
  range: 10,
  length: 10,
  width: 0.5,
  damage: 0.6,
  projectiles: 5,
  maxHitsPerTarget: 3,
  speed: 18,
});
add("ปล่อยลูกพลังช้ำ", "slowOrb", {
  range: 10,
  length: 10,
  radius: 1,
  damage: 0.65,
  duration: 5,
  interval: 1,
  speed: 4,
});
add("ทำเครื่องหมำยวงรัศมี 4 ม. ระยะ 12 ม.; หลัง 1 ", "circle", {
  range: 12,
  radius: 4,
  damage: 3.3,
  cast: 1,
});
add("ทำเครื่องหมำยวงรัศมี 4 ม. ระยะ 12 ม.; หลัง 0.8", "circleMulti", {
  range: 12,
  radius: 4,
  damage: 0.7,
  cast: 0.8,
  hits: 4,
  interval: 0.2,
});
add("ยืนร่ำยลำแสง", "beam", {
  range: 12,
  length: 12,
  width: 1,
  damage: 1,
  hits: 3,
  interval: 0.5,
  channel: 1.5,
});
add("คงกำรร่ำยรัศมี", "circleChannel", {
  range: 0,
  radius: 4,
  damage: 0.7,
  hits: 4,
  interval: 0.5,
  channel: 2,
});
add("วำงทุ่น", "mine", {
  range: 8,
  radius: 2,
  damage: 1.5,
  cap: 3,
  recast: true,
});
add("พรำงตัว", "stealth", { range: 0, duration: 3, revealRange: 2 });
add("ระเบิดวง 3 ม.", "circle", {
  range: 8,
  radius: 3,
  damage: 1,
  control: { tag: "blind", duration: 2, pct: 20 },
});
add("สร้ำงวัตถุสำม", "orbit", {
  range: 0,
  radius: 2,
  damage: 0.9,
  duration: 5,
  projectiles: 3,
});
add("อัญเชิญผู้ติดตำม", "summon", {
  range: 0,
  duration: 8,
  hp: 0.25,
  damage: 0.55,
  interval: 1,
  unitRange: 8,
  cap: 2,
  group: "follower",
});
add("สั่งผู้ติดตำม", "command", { range: 12, damage: 1.8 });
add("สละผู้ติดตำม", "sacrifice", { range: 10, radius: 4, damage: 3 });
add("ฝังเมล็ด", "seed", {
  range: 10,
  radius: 1,
  duration: 6,
  damage: 1.7,
  heal: 0.9,
});
add("โจมตีเป้ำหมำยระยะ 12 ม. 80", "delayed", {
  range: 12,
  damage: 0.8,
  delay: 2,
  delayedDamage: 2,
});
add("กำหนดวงรัศมี 7", "rain", {
  range: 14,
  radius: 7,
  cast: 1.2,
  hits: 6,
  interval: 0.3,
  damage: 1.7,
});
add("ยิงกระสุน 150", "chain", {
  range: 12,
  damage: 1.5,
  secondary: 1.5,
  maxTargets: 4,
  chainRange: 4,
  speed: 18,
});
add("เรียกผู้ติดตำมทั้งหมด", "recall", { range: 0, healHp: 0.25 });
add("วำงจุดย้ำย", "portal", { range: 10, duration: 5, recast: true });
add("สร้ำงร่ำงจำลอง", "clone", {
  range: 0,
  duration: 5,
  hp: 0.2,
  damage: 0.35,
  cap: 1,
  group: "clone",
});
add("สลับตำแหน่ง", "swap", { range: 10 });
add("ร่ำย 1 วินำที สร้ำงเขต", "sanctuary", {
  range: 0,
  radius: 7,
  duration: 7,
  cast: 1,
  heal: 0.9,
  interval: 1,
  maxRemove: 1,
});
add("เปลี่ยนรูปแบบ", "morph", {
  range: 0,
  duration: 5,
  damage: 1.1,
  radius: 2,
});
add("ยิงเป้ำหมำยระยะ 10 ม. 100% D และพิษ", "single", {
  range: 10,
  damage: 1,
  dot: { damage: 0.35, duration: 4, interval: 1, tag: "poison" },
  speed: 18,
});
add("ขว้ำงลูกระเบิด", "grenade", {
  range: 10,
  radius: 3,
  cast: 0.6,
  damage: 2.3,
});
add("วำงหุ่นล่อ", "decoy", {
  range: 0,
  duration: 5,
  hp: 0.2,
  deathDamage: 1.4,
  radius: 2,
  cap: 1,
  group: "decoy",
});
add("ทำสำเนำสกิล", "echo", { range: 0, delay: 1, fraction: 0.45 });
add("เล็งนิ่ง", "snipe", {
  range: 18,
  length: 18,
  width: 0.5,
  cast: 1,
  damage: 3.6,
  maxTargets: 1,
});
add("ใช้เวลำ 0.7", "reload", { range: 0, cast: 0.7 });
add("ติดตั้งป้อม 8", "turret", {
  range: 0,
  duration: 8,
  hp: 0.25,
  damage: 0.6,
  interval: 1,
  unitRange: 10,
  cap: 2,
  group: "turret",
});
add("ติดตั้งป้อมสำย", "turret", {
  range: 0,
  duration: 8,
  hp: 0.25,
  damage: 0.45,
  secondary: 0.2,
  chainRange: 4,
  maxTargets: 2,
  interval: 1,
  unitRange: 10,
  cap: 2,
  group: "turret",
});
add("ติดตั้งป้อมปืน", "mortar", {
  range: 0,
  duration: 8,
  hp: 0.25,
  damage: 1.1,
  interval: 2,
  unitRange: 10,
  radius: 2,
  warning: 0.5,
  cap: 2,
  group: "turret",
});
add("สร้ำงโดรนซ่อม", "repairDrone", {
  range: 0,
  duration: 8,
  hp: 0.25,
  healHp: 0.06,
  interval: 1,
  unitRange: 6,
  cap: 2,
  group: "follower",
});
add("อัญเชิญหมำป่ำ", "summon", {
  range: 0,
  duration: 12,
  hp: 0.35,
  damage: 0.55,
  interval: 1,
  unitRange: 1.6,
  cap: 1,
  group: "companion",
});
add("อัญเชิญหมี", "summon", {
  range: 0,
  duration: 12,
  hp: 0.5,
  damage: 0.65,
  interval: 1.5,
  unitRange: 1.6,
  cap: 1,
  group: "companion",
  commandPush: 1,
});
add("อัญเชิญเหยี่ยว", "summon", {
  range: 0,
  duration: 12,
  hp: 0.25,
  damage: 0.45,
  interval: 1,
  unitRange: 8,
  cap: 1,
  group: "companion",
});
add("บันทึกตำแหน่ง", "rewind", {
  range: 0,
  duration: 3,
  healHp: 0.15,
  recast: true,
});
add("สร้ำงเขตรัศมี 4 ม. นำน 4", "slowZone", {
  range: 0,
  radius: 4,
  duration: 4,
  interval: 1,
  control: { tag: "slow", pct: 35, duration: 1.1 },
});
add("บันทึกจุดยืน", "partyRewind", {
  range: 0,
  radius: 6,
  duration: 3,
  maxTargets: 5,
  healHp: 0.2,
  consent: true,
});
add("อัญเชิญปีศำจประชิด", "summon", {
  range: 0,
  duration: 8,
  hp: 0.35,
  damage: 0.8,
  interval: 1.5,
  unitRange: 1.6,
  cap: 2,
  group: "follower",
});
module.exports = {
  templates,
  army: {
    type: "army",
    range: 0,
    duration: 8,
    hp: 0.2,
    damage: 0.3,
    interval: 1,
    unitRange: 8,
    cap: 5,
    group: "army",
  },
};
