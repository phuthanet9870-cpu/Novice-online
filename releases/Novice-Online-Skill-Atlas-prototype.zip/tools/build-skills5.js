'use strict';
// Build the PDF skill atlas. Legacy kits are reference material only and are never registered.
require('./atlas/build');
