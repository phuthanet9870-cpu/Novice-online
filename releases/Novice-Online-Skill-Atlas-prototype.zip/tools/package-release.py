"""Package source, assets and the generated HTML. Never package player saves or credentials."""
from pathlib import Path
import argparse, hashlib, json, zipfile
root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--output', required=True)
a = p.parse_args()
output = Path(a.output).resolve()
if not (root / 'dist/novice-online.html').exists():
    raise SystemExit('Run npm run build:artifact first')
excluded = {'.git', 'node_modules', 'data', 'dist', '__pycache__', '.npm-cache'}
entries = []
for path in sorted(root.rglob('*')):
    relative = path.relative_to(root)
    if any(part in excluded for part in relative.parts) or path.is_symlink() or not path.is_file():
        continue
    if path.resolve() == output or path.suffix in {'.zip', '.tmp', '.log', '.bak'}:
        continue
    if relative.as_posix() == 'index.html':
        continue
    entries.append((path, relative.as_posix()))
entries.append((root / 'dist/novice-online.html', 'index.html'))
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for path, name in entries}
output.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path, name in entries:
        z.write(path, name)
    z.writestr('RELEASE-MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    assert 'index.html' in z.namelist() and 'server/atlas.js' in z.namelist()
    assert not any(n.startswith(('data/', '.git/', 'node_modules/')) for n in z.namelist())
    source = json.loads(z.read('docs/skill-atlas/source.json'))
    assert len(source['skills']) == len({s['id'] for s in source['skills']}) == 1650
    for path, name in entries:
        assert hashlib.sha256(z.read(name)).hexdigest() == manifest[name], name
print(json.dumps({'path': str(output), 'files': len(entries)+1, 'bytes': output.stat().st_size, 'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}, indent=2))
